package com;

final class ConsumerTask<T> /*extends ForkJoinTask<Void> */implements Runnable/*, CompletableFuture.AsynchronousCompletionTask*/ {
    final BufferedSubscription<T> consumer;

    ConsumerTask(BufferedSubscription<T> consumer) {
        this.consumer = consumer;
    }

    //    public final Void getRawResult() {
//        return null;
//    }
//
//    public final void setRawResult(Void v) {
//    }
//
//    public final boolean exec() {
//        consumer.consume();
//        return false;
//    }
//
    @Override
    public final void run() {
        consumer.consume();
    }
}
