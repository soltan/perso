package com;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

public class MyLinkedBlockingQueue<E> {

    static class Node<E> {
        E item;
        Node<E> next;

        Node(E x) {
            item = x;
        }
    }

//    private final AtomicInteger count = new AtomicInteger();
//    transient Node<E> head;
//    private transient Node<E> last;
//    private final ReentrantLock takeLock = new ReentrantLock();
//    private final Condition notEmpty = takeLock.newCondition();
//    private final ReentrantLock putLock = new ReentrantLock();
//    private final Condition notFull = putLock.newCondition();

    private static final VarHandle QA = MethodHandles.arrayElementVarHandle(Object[].class);
    private volatile int qhead;
    private volatile int qtail;
    private final int capacity;
    private final Object[] array; // must have exact type Object[]

    public MyLinkedBlockingQueue(Class<E> clazz) {
        this(clazz, 16);
    }

    public MyLinkedBlockingQueue(Class<E> clazz, int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException();
        this.capacity = capacity;
//        last = head = new Node<E>(null);
        this.array = new Object[capacity];
    }

    //    private void signalNotEmpty() {
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lock();
//        try {
//            notEmpty.signal();
//        } finally {
//            takeLock.unlock();
//        }
//    }
//
//    public boolean isEmpty() {
//        return size() == 0;
//    }
//
//    private void signalNotFull() {
//        final ReentrantLock putLock = this.putLock;
//        putLock.lock();
//        try {
//            notFull.signal();
//        } finally {
//            putLock.unlock();
//        }
//    }
//
//    private void enqueue(Node<E> node) {
//        last = last.next = node;
//    }
//
//    private E dequeue() {
//        Node<E> h = head;
//        Node<E> first = h.next;
//        h.next = h; // help GC
//        head = first;
//        E x = first.item;
//        first.item = null;
//        return x;
//    }
//
//    void fullyLock() {
//        putLock.lock();
//        takeLock.lock();
//    }
//
//    void fullyUnlock() {
//        takeLock.unlock();
//        putLock.unlock();
//    }
//
//
//    public int size() {
//        return count.get();
//    }
//
    public boolean offer(E e, long timeout, TimeUnit unit) throws InterruptedException {
        if (e == null) throw new NullPointerException();
        long nanos = unit.toNanos(timeout);
        final int c;
        putLock.lockInterruptibly();
        try {
//            while (count.get() == capacity) {
//                if (nanos <= 0L)
//                    return false;
//                nanos = notFull.awaitNanos(nanos);
//            }
//            enqueue(new Node<E>(e));
//            c = count.getAndIncrement();
//            if (c + 1 < capacity)
//                notFull.signal();
        } finally {
            putLock.unlock();
        }
        if (c == 0) {
            signalNotEmpty();
        }
        return true;
    }


    final int offer(E e, long timeout, TimeUnit unit) {
        if (e == null) throw new NullPointerException();
        long nanos = unit.toNanos(timeout);
        Object[] a;
        int stat = 0;
        int t = qtail, i = t & (capacity - 1), n = t + 1 - qhead;
        for(;;)
        boolean added;
        if (n >= capacity)      // need volatile CAS
            added = QA.compareAndSet(a, i, null, item);
        else {                             // can use release mode
            QA.setRelease(a, i, e);
            added = true;
        }
        if (added) {
            qtail = t + 1;
            stat = n;
        }
        return 0;// startOnOffer(stat);
    }
//
//    public boolean offer(E e) {
//        if (e == null) throw new NullPointerException();
//        final AtomicInteger count = this.count;
//        if (count.get() == capacity)
//            return false;
//        final int c;
//        final Node<E> node = new Node<E>(e);
//        final ReentrantLock putLock = this.putLock;
//        putLock.lock();
//        try {
//            if (count.get() == capacity)
//                return false;
//            enqueue(node);
//            c = count.getAndIncrement();
//            if (c + 1 < capacity)
//                notFull.signal();
//        } finally {
//            putLock.unlock();
//        }
//        if (c == 0)
//            signalNotEmpty();
//        return true;
//    }
//
//    public E take() throws InterruptedException {
//        final E x;
//        final int c;
//        final AtomicInteger count = this.count;
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lockInterruptibly();
//        try {
//            while (count.get() == 0) {
//                notEmpty.await();
//            }
//            x = dequeue();
//            c = count.getAndDecrement();
//            if (c > 1)
//                notEmpty.signal();
//        } finally {
//            takeLock.unlock();
//        }
//        if (c == capacity)
//            signalNotFull();
//        return x;
//    }
//
//    public E poll(long timeout, TimeUnit unit) throws InterruptedException {
//        final E x;
//        final int c;
//        long nanos = unit.toNanos(timeout);
//        final AtomicInteger count = this.count;
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lockInterruptibly();
//        try {
//            while (count.get() == 0) {
//                if (nanos <= 0L)
//                    return null;
//                nanos = notEmpty.awaitNanos(nanos);
//            }
//            x = dequeue();
//            c = count.getAndDecrement();
//            if (c > 1)
//                notEmpty.signal();
//        } finally {
//            takeLock.unlock();
//        }
//        if (c == capacity) {
//            signalNotFull();
//        }
//        return x;
//    }
//
//    public E poll() {
//        final AtomicInteger count = this.count;
//        if (count.get() == 0)
//            return null;
//        final E x;
//        final int c;
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lock();
//        try {
//            if (count.get() == 0)
//                return null;
//            x = dequeue();
//            c = count.getAndDecrement();
//            if (c > 1)
//                notEmpty.signal();
//        } finally {
//            takeLock.unlock();
//        }
//        if (c == capacity)
//            signalNotFull();
//        return x;
//    }
//
//    public E peek() {
//        final AtomicInteger count = this.count;
//        if (count.get() == 0)
//            return null;
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lock();
//        try {
//            return (count.get() > 0) ? head.next.item : null;
//        } finally {
//            takeLock.unlock();
//        }
//    }
//
//
//    void unlink(Node<E> p, Node<E> pred) {
//        // assert putLock.isHeldByCurrentThread();
//        // assert takeLock.isHeldByCurrentThread();
//        // p.next is not changed, to allow iterators that are
//        // traversing p to maintain their weak-consistency guarantee.
//        p.item = null;
//        pred.next = p.next;
//        if (last == p)
//            last = pred;
//        if (count.getAndDecrement() == capacity)
//            notFull.signal();
//    }
//
//    public boolean remove(Object o) {
//        if (o == null) return false;
//        fullyLock();
//        try {
//            for (Node<E> pred = head, p = pred.next;
//                 p != null;
//                 pred = p, p = p.next) {
//                if (o.equals(p.item)) {
//                    unlink(p, pred);
//                    return true;
//                }
//            }
//            return false;
//        } finally {
//            fullyUnlock();
//        }
//    }
//
//    @SuppressWarnings("unchecked")
//    public <T> T[] toArray(T[] a) {
//        fullyLock();
//        try {
//            int size = count.get();
//            if (a.length < size)
//                a = (T[]) java.lang.reflect.Array.newInstance
//                        (a.getClass().getComponentType(), size);
//
//            int k = 0;
//            for (Node<E> p = head.next; p != null; p = p.next)
//                a[k++] = (T) p.item;
//            if (a.length > k)
//                a[k] = null;
//            return a;
//        } finally {
//            fullyUnlock();
//        }
//    }
//
//    public int drainTo(Collection<? super E> c) {
//        return drainTo(c, Integer.MAX_VALUE);
//    }
//
//    public int drainTo(Collection<? super E> c, int maxElements) {
//        Objects.requireNonNull(c);
//        if (c == this)
//            throw new IllegalArgumentException();
//        if (maxElements <= 0)
//            return 0;
//        boolean signalNotFull = false;
//        final ReentrantLock takeLock = this.takeLock;
//        takeLock.lock();
//        try {
//            int n = Math.min(maxElements, count.get());
//            // count.get provides visibility to first n Nodes
//            Node<E> h = head;
//            int i = 0;
//            try {
//                while (i < n) {
//                    Node<E> p = h.next;
//                    c.add(p.item);
//                    p.item = null;
//                    h.next = h;
//                    h = p;
//                    ++i;
//                }
//                return n;
//            } finally {
//                // Restore invariants even if c.add() threw
//                if (i > 0) {
//                    // assert h.item == null;
//                    head = h;
//                    signalNotFull = (count.getAndAdd(-i) == capacity);
//                }
//            }
//        } finally {
//            takeLock.unlock();
//            if (signalNotFull)
//                signalNotFull();
//        }
//    }
////    private void writeObject(java.io.ObjectOutputStream s)
////            throws java.io.IOException {
////        fullyLock();
////        try {
////            // Write out any hidden stuff, plus capacity
////            s.defaultWriteObject();
////
////            // Write out all elements in the proper order.
////            for (java.util.concurrent.LinkedBlockingQueue.Node<E> p = head.next; p != null; p = p.next)
////                s.writeObject(p.item);
////
////            // Use trailing null as sentinel
////            s.writeObject(null);
////        } finally {
////            fullyUnlock();
////        }
////    }
////
////    private void readObject(java.io.ObjectInputStream s)
////            throws java.io.IOException, ClassNotFoundException {
////        // Read in capacity, and any hidden stuff
////        s.defaultReadObject();
////
////        count.set(0);
////        last = head = new java.util.concurrent.LinkedBlockingQueue.Node<E>(null);
////
////        // Read in all elements and place in queue
////        for (;;) {
////            @SuppressWarnings("unchecked")
////            E item = (E)s.readObject();
////            if (item == null)
////                break;
////            add(item);
////        }
////    }

    // VarHandle mechanics
    private static final VarHandle STATE;
    private static final VarHandle QHEAD;
    private static final VarHandle QTAIL;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            STATE = l.findVarHandle(MyLinkedBlockingQueue.Worker.class, "state", long.class);
            QHEAD = l.findVarHandle(MyLinkedBlockingQueue.class, "qhead", long.class);
            QTAIL = l.findVarHandle(MyLinkedBlockingQueue.Worker.class, "qtail", long.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
        // Reduce the risk of rare disastrous classloading in first call to
        // LockSupport.park: https://bugs.openjdk.java.net/browse/JDK-8074773
        Class<?> ensureLoaded = LockSupport.class;
    }

}
