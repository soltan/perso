package com.erpos.orm.jdbc.pool.management;

import javax.management.MXBean;

@MXBean
public interface JdbcPoolMXBean {

    int getActiveConnections();

    int getIdleConnections();

    int getTotalConnections();

    int getThreadsAwaitingConnection();

    void softEvictConnections();

}
