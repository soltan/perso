package com.erpos.orm.jdbc.pool;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.sql.SQLException;
import java.sql.SQLTransientConnectionException;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static java.util.Objects.nonNull;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

final class JdbcPool extends BaseJdbcPool {

    private static final String EVICTED_CONNECTION_MESSAGE = "(connection was evicted)";
    private static final String DEAD_CONNECTION_MESSAGE = "(connection is dead)";
    private static final String[] RESET_STATES = {"readOnly", "autoCommit", "isolation", "catalog", "netTimeout", "schema"};

    private static final VarHandle AC = MethodHandles.arrayElementVarHandle(JdbcConnection[].class);
    private static final Function<Object, JdbcConnection> LC_CAST = JdbcConnection.class::cast;

    private static final int STATS_IDLE_SHIFT = 16;
    private static final int STATS_IDLE_UNIT = (1 << STATS_IDLE_SHIFT);
    private static final int STATS_MASK = STATS_IDLE_UNIT - 1;

    private final long ALIVE_BYPASS_WINDOW_MS = Long.getLong("com.zaxxer.hikari.aliveBypassWindowMs", MILLISECONDS.toMillis(500));

    @jdk.internal.vm.annotation.Contended("c") // segregate
    private volatile int waiters;              // # unfilled requests
    @jdk.internal.vm.annotation.Contended("c")
    private volatile int waiting;              // nonzero if producer blocked
    @jdk.internal.vm.annotation.Contended("c")
    private volatile int ctl;                  // atomic run state flags
    @jdk.internal.vm.annotation.Contended("c")
    private volatile int idlesConnections;                  // atomic run state flags

    private final int maxConnections;
    private final JdbcConnection[] connections;
    private final JdbcConnection[] idlesConnectionsQueue;

    JdbcPool(final JdbcConfig config) {
        super(config);
        this.maxConnections = config.getMaximumPoolSize();
        this.connections = new JdbcConnection[maxConnections];
        this.idlesConnectionsQueue = new JdbcConnection[maxConnections];
    }

    String getPoolName() {
        return config.getPoolName();
    }

    public int getIdlesConnections() {
        return idlesConnections;
    }

//    public int getTotalConnections() {
//        return (statsConnections & STATS_MASK);
//    }

    public JdbcConnection getConnection() throws SQLException {
        return getConnection(config.getConnectionTimeout());
    }

    public JdbcConnection getConnection(final long timoutMs) throws SQLException {
        return getConnection(config.getConnectionTimeout(), TimeUnit.MILLISECONDS);
    }

    public JdbcConnection getConnection(final long hardTimout, final TimeUnit timeUnit) throws SQLException {
        final Instant startTime = Instant.now();
        final long hardTimoutMs = timeUnit.toMillis(hardTimout);
        final Instant endTime = startTime.plusMillis(hardTimout);
        final Instant now = startTime;

        JdbcConnection conn;
        long epochMs = 0;
        try {
        do {
            if (nonNull(conn = getNotInUseEntry(STATE_NOT_IN_USE, STATE_IN_USE))) {
                if (((epochMs = now.toEpochMilli()) - conn.getLastAccessed()) > ALIVE_BYPASS_WINDOW_MS && !isConnectionAlive(conn.getPhysicalConnection())) {
                    closeConnection(conn, conn.isMarkedEvicted() ? EVICTED_CONNECTION_MESSAGE : DEAD_CONNECTION_MESSAGE);
                } else {
                    conn.setLastAccessed(epochMs);
                    return conn;//.createProxyConnection(leakTaskFactory.schedule(poolEntry), now);
                }
            }
        } while(endTime.isAfter(Instant.now()));
            throw createTimeoutException(Duration.between(startTime, endTime).toMillis());
        ////} catch (InterruptedException ex) {
        ////    Thread.currentThread().interrupt();
        ////    throw new SQLException(getPoolName() + " - Interrupted during connection acquisition", ex);
        } finally {
            //addWaitersAndGet(-1);
        }
    }

    protected final JdbcConnection getPoolEntry(int i) {
        return LC_CAST.apply(AC.getVolatile(connections, i));
    }

    public JdbcConnection getNotInUseEntry(final int expectedState, final int newState) {
        JdbcConnection e;
        for (int i = 0; i < maxConnections && getIdlesConnections() > 0; i++) {
            if ((e = getPoolEntry(i)) != null && e.compareAndSet(expectedState, newState)) {
                return e;
            }
        }
        return null;
    }

    public void addBagItem(final int waiting) throws InterruptedException {
        if (waiting - this.getIdlesConnections() >= 0) {
            //addConnectionExecutor.submit(POOL_ENTRY_CREATOR);
        }
    }

    void closeConnection(final JdbcConnection conn, final String closureReason) {
//        if (remove(poolEntry)) {
//            final Connection connection = poolEntry.closeEntry();
//            closeConnectionExecutor.execute(() -> {
//                quietlyCloseConnection(connection, closureReason);
//                if (poolState == POOL_NORMAL) {
//                    fillPool();
//                }
//            });
//        }
    }

    private SQLException createTimeoutException(long timeMs) {
        String sqlState = null;
        final Throwable originalException = getLastConnectionFailure();
        if (originalException instanceof SQLException) {
            sqlState = ((SQLException) originalException).getSQLState();
        }
        final SQLException connectionException = new SQLTransientConnectionException(getPoolName() +
                " - Connection is not available, request timed out after " + timeMs + "ms.", sqlState, originalException);
        if (originalException instanceof SQLException) {
            connectionException.setNextException((SQLException) originalException);
        }
        return connectionException;
    }

    void recycle(JdbcConnection jdbcConnection) {

    }
}
