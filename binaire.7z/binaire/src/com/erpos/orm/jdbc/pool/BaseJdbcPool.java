package com.erpos.orm.jdbc.pool;

import com.erpos.common.util.Utils;
import com.erpos.log.Logger;
import com.erpos.log.LoggerFactory;
import com.erpos.orm.jdbc.DriverDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLTransientConnectionException;
import java.util.Properties;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

//import static com.erpos.orm.jdbc.pool.JdbcConnection.*;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;

abstract class BaseJdbcPool /*implements JdbcPoolMXBean, Closeable*/ {

    protected static final Logger LOGGER = LoggerFactory.getLogger("JdbcPool");
    protected static final int UNINITIALIZED = -1;
//
//    private static final VarHandle AA = MethodHandles.arrayElementVarHandle(long[].class);
//    private static final VarHandle AC = MethodHandles.arrayElementVarHandle(JdbcConnection[].class);
//    //
//    private static final int NCPU = Runtime.getRuntime().availableProcessors();
//    private static final int SPINS = (NCPU > 1) ? 1 << 6 : 1;
//    private static final long SPIN_FOR_TIMEOUT_THRESHOLD = 1000L;
//    //
////
    static final int STATE_NOT_IN_USE = 0;
    static final int STATE_IN_USE = 1;
    static final int STATE_REMOVED = 2;
    static final int STATE_RESERVED = 3;
//    private static final int BITSHIFT = 5;
//    private static final int BITMASK = (1 << BITSHIFT) - 1;
//
    protected final JdbcConfig config;
//    protected final JdbcConnection[] connections;
    protected final DataSource dataSource;
    protected final AtomicReference<Throwable> lastConnectionFailure;
//    //
    private final int networkTimeout;
    private final int defaultTransactionIsolation;
    //
//    private final long[] states;
//    private final long nanos;
//
    protected final ThreadFactory threadFactory;
    protected final Executor netTimeoutExecutor;

    protected BaseJdbcPool(final JdbcConfig config) {
        this.config = config;
        this.lastConnectionFailure = new AtomicReference<>();
        this.threadFactory = new Utils.DefaultThreadFactory(config.getPoolName() + " executor", true);
        this.dataSource = initializeDataSource();
        this.netTimeoutExecutor = createNetworkTimeoutExecutor(dataSource, config.getJdbcUrl());
        Connection connection = null;
        try {
            String username = config.getUsername();
            String password = config.getPassword();
            connection = (username == null) ? dataSource.getConnection() : dataSource.getConnection(username, password);
            if (connection == null) {
                throw new SQLTransientConnectionException("DataSource returned null unexpectedly");
            }
            if (config.getCatalog() != null) {
                connection.setCatalog(config.getCatalog());
            }
            if (config.getSchema() != null) {
                connection.setSchema(config.getSchema());
            }
            if (!connection.isReadOnly()) {
                connection.setReadOnly(true);
            }
            if (connection.getAutoCommit()) {
                connection.setAutoCommit(true);
            }
            int transactionIsolation;
            try {
                transactionIsolation = connection.getTransactionIsolation();
            } catch (SQLException e) {
                LOGGER.warn("{} - Default transaction isolation level detection failed ({}).", config.getPoolName(), e.getMessage());
                if (e.getSQLState() != null && !e.getSQLState().startsWith("08")) {
                    throw e;
                }
                transactionIsolation = config.getTransactionIsolation();
            }
            this.defaultTransactionIsolation = transactionIsolation;
            connection.setTransactionIsolation(transactionIsolation);
            int maxConnections = connection.getMetaData().getMaxConnections();
            if (maxConnections > 0) {
                this.config.setMaximumPoolSize(maxConnections);
            }
            long validationTimeout = config.getValidationTimeout();
            this.networkTimeout = getAndSetNetworkTimeout(connection, validationTimeout);
            this.setNetworkTimeout(connection, validationTimeout);
            connection.isValid(1);
//            ////executeSql(connection, config.getConnectionInitSql(), true);
            this.setNetworkTimeout(connection, networkTimeout);
        } catch (Throwable e) {
            LOGGER.error("{} - Exception during pool initialization.", config.getPoolName(), e);
            if (connection != null) {
                quietlyCloseConnection(connection, "(Failed to create/setup connection)");
            }
            throw new PoolInitializationException(e);
        }
//        this.nanos = 0;// config.getMaximumPoolSize();
//        final int maximumPoolSize = config.getMaximumPoolSize();
//        this.connections = new JdbcConnection[maximumPoolSize];
//        final int need = (maximumPoolSize + BITMASK) >> BITSHIFT;
//        this.states = new long[need];
////        //        this.lock = new StampedLock();
//////        this.networkTimeout = UNINITIALIZED;
////        this.transactionIsolation = config.getTransactionIsolation();
//////        this.isNetworkTimeoutSupported = UNINITIALIZED;
//////        this.isIsolateInternalQueries = config.isIsolateInternalQueries();
////////    this.connectionTimeout = config.getConnectionTimeout();
////////        this.validationTimeout = config.getValidationTimeout();
//////        this.waiters = new AtomicInteger();
//////        this.threadJdbcConnection = new ThreadLocal<>();
//////        this.handoffQueue = new SynchronousQueue<>(true);
//
    }
//
//    public String getPoolName() {
//        return config.getPoolName();
//    }
//
    protected final Throwable getLastConnectionFailure() {
        return lastConnectionFailure.get();
    }
//
//    protected final JdbcConnection getPoolEntry(int i) {
//        return (JdbcConnection) AC.getVolatile(connections, i);
//    }
//
//    //    protected final void setPoolEntry(int i, JdbcConnection newValue) {
////        AC.setVolatile(jdbcConnections, i, newValue);
////    }
////
////    protected final JdbcConnection getAndSetPoolEntry(int i, JdbcConnection newValue) {
////        return (JdbcConnection) AC.getAndSet(jdbcConnections, i, newValue);
////    }
////
////    protected final boolean compareAndSet(int i, JdbcConnection expectedValue, JdbcConnection newValue) {
////        return AC.compareAndSet(jdbcConnections, i, expectedValue, newValue);
////    }
////
////    protected final JdbcConnection getAndUpdate(int i, UnaryOperator<JdbcConnection> updateFunction) {
////        JdbcConnection prev = getPoolEntry(i), next = null;
////        for (boolean haveNext = false; ; ) {
////            if (!haveNext) {
////                next = updateFunction.apply(prev);
////            }
////            if (compareAndSet(i, prev, next)) {
////                return prev;
////            }
////            haveNext = (prev == (prev = getPoolEntry(i)));
////        }
////    }
////
////    protected final JdbcConnection updateAndGet(int i, UnaryOperator<JdbcConnection> updateFunction) {
////        JdbcConnection prev = getPoolEntry(i), next = null;
////        for (boolean haveNext = false; ; ) {
////            if (!haveNext) {
////                next = updateFunction.apply(prev);
////            }
////            if (compareAndSet(i, prev, next)) {
////                return next;
////            }
////            haveNext = (prev == (prev = getPoolEntry(i)));
////        }
////    }
////
    public static class PoolInitializationException extends RuntimeException {
        private static final long serialVersionUID = 929872118275916520L;

        public PoolInitializationException(Throwable t) {
            super("Failed to initialize pool: " + t.getMessage(), t);
        }
    }

    private DataSource initializeDataSource() {
        final String jdbcUrl = config.getJdbcUrl();
        final String username = config.getUsername();
        final String password = config.getPassword();
        final String driverClassName = config.getDriverClassName();
        final Properties dataSourceProperties = config.getDataSourceProperties();
        final DataSource dataSource = new DriverDataSource(jdbcUrl, driverClassName, dataSourceProperties, username, password);
        long connectionTimeout;
        if ((connectionTimeout = config.getConnectionTimeout()) < Integer.MAX_VALUE) {
            try {
                dataSource.setLoginTimeout(Math.max(1, (int) MILLISECONDS.toSeconds(500L + connectionTimeout)));
            } catch (Throwable e) {
                LOGGER.info("{} - Failed to set login timeout for data source. ({})", config.getPoolName(), e.getMessage());
            }
        }
        return dataSource;
    }

    private ThreadPoolExecutor createNetworkTimeoutExecutor(final DataSource dataSource, final String jdbcUrl) {
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool(threadFactory);
        executor.setKeepAliveTime(15, SECONDS);
        executor.allowCoreThreadTimeOut(true);
        return executor;
    }
//
//    protected final Connection newConnection() throws Exception {
//        Connection connection = null;
//        try {
//            String username = config.getUsername();
//            String password = config.getPassword();
//            connection = (username == null) ? dataSource.getConnection() : dataSource.getConnection(username, password);
//            if (connection == null) {
//                throw new SQLTransientConnectionException("DataSource returned null unexpectedly");
//            }
//            setupConnection(connection);
//            lastConnectionFailure.set(null);
//            return connection;
//        } catch (Exception e) {
//            if (connection != null) {
//                quietlyCloseConnection(connection, "(Failed to create/setup connection)");
//            } else if (lastConnectionFailure.get() == null) {
//                LOGGER.debug("{} - Failed to create/setup connection: {}", config.getPoolName(), e.getMessage());
//            }
//            lastConnectionFailure.set(e);
//            throw e;
//        }
//    }
//
//    private void setupConnection(final Connection connection) throws ConnectionSetupException {
//        try {
//            long validationTimeout = config.getValidationTimeout();
//            setNetworkTimeout(connection, validationTimeout);
//            boolean isReadOnly = config.isReadOnly();
//            if (connection.isReadOnly() != isReadOnly) {
//                connection.setReadOnly(isReadOnly);
//            }
//            boolean isAutoCommit = config.isAutoCommit();
//            if (connection.getAutoCommit() != isAutoCommit) {
//                connection.setAutoCommit(isAutoCommit);
//            }
//            int transactionIsolation = config.getTransactionIsolation();
//            if (transactionIsolation != defaultTransactionIsolation) {
//                connection.setTransactionIsolation(transactionIsolation);
//            }
//            if (config.getCatalog() != null) {
//                connection.setCatalog(config.getCatalog());
//            }
//            if (config.getSchema() != null) {
//                connection.setSchema(config.getSchema());
//            }
//            ////executeSql(connection, config.getConnectionInitSql(), true);
//            setNetworkTimeout(connection, networkTimeout);
//        } catch (SQLException e) {
//            throw new ConnectionSetupException(e);
//        }
//    }
//
    private int getAndSetNetworkTimeout(final Connection connection, final long timeoutMs) {
        try {
            final int originalTimeout = connection.getNetworkTimeout();
            connection.setNetworkTimeout(netTimeoutExecutor, (int) timeoutMs);
            return originalTimeout;
        } catch (Throwable e) {
            long validationTimeout = config.getValidationTimeout();
            LOGGER.info("{} - Driver does not support get/set network timeout for connections. ({})", config.getPoolName(), e.getMessage());
            if (validationTimeout < SECONDS.toMillis(1)) {
                LOGGER.warn("{} - A validationTimeout of less than 1 second cannot be honored on drivers without setNetworkTimeout() support.", config.getPoolName());
            } else if (validationTimeout % SECONDS.toMillis(1) != 0) {
                LOGGER.warn("{} - A validationTimeout with fractional second granularity cannot be honored on drivers without setNetworkTimeout() support.", config.getPoolName());
            }
            return 0;
        }
    }

    protected final void quietlyCloseConnection(final Connection connection, final String closureReason) {
        if (connection != null) {
            try {
                LOGGER.debug("{} - Closing connection {}: {}", config.getPoolName(), connection, closureReason);
                try {
                    setNetworkTimeout(connection, TimeUnit.SECONDS.toMillis(15));
                } catch (SQLException e) {
                    // ignore
                } finally {
                    connection.close(); // continue with the close even if setNetworkTimeout() throws
                }
            } catch (Throwable e) {
                LOGGER.debug("{} - Closing connection {} failed", config.getPoolName(), connection, e);
            }
        }
    }

    protected final void setNetworkTimeout(final Connection connection, final long timeoutMs) throws SQLException {
        if (networkTimeout != UNINITIALIZED) {
            connection.setNetworkTimeout(netTimeoutExecutor, (int) timeoutMs);
        }
    }


    protected boolean isConnectionAlive(final Connection connection) {
        try {
            try {
                long validationTimeout = config.getValidationTimeout();
                setNetworkTimeout(connection, validationTimeout);
                final int validationSeconds = (int) Math.max(1000L, validationTimeout) / 1000;
                return connection.isValid(validationSeconds);
            } finally {
                setNetworkTimeout(connection, networkTimeout);
            }
        } catch (Exception e) {
            lastConnectionFailure.set(e);
            LOGGER.warn("{} - Failed to validate connection {} ({}). Possibly consider using a shorter maxLifetime value.",
                    config.getPoolName(), connection, e.getMessage());
            return false;
        }
    }
////
//    private int getState(final int index) {
//        int slotIndex = index >> BITSHIFT;
//        long word = (long) AA.getVolatile(states, slotIndex);
//        int bit = (index & BITMASK) << 1;
//        return Math.toIntExact(0x3 & (word >> bit));
//    }
//
//    private boolean tryWriteLock(final int slotIndex, final long word, final long newValue) {
//        if (AA.compareAndSet(states, slotIndex, word, newValue)) {
//            VarHandle.storeStoreFence();
//            return true;
//        }
//        return false;
//    }
//
//    private void setState(final int index, int state) throws InterruptedException {
//        final long deadline = System.nanoTime() + nanos;
//        final int slotIndex = index >> BITSHIFT;
//        final int bit1 = (index & BITMASK) << 1;
//        final int bit2 = bit1 + 1;
//        long word, newValue, nanos;
//        for (int spins = -1; ; ) {
//            word = (long) AA.getVolatile(states, slotIndex);
//            newValue = newState(word, bit1, bit2, state);
//            if (tryWriteLock(slotIndex, word, newValue)) {
//                return;
//            } else if (spins < 0) {
//                spins = SPINS;
//            } else if (spins > 0) {
//                --spins;
//                Thread.onSpinWait();
//            } else {
//                spins = SPINS;
//                if ((nanos = deadline - System.nanoTime()) <= 0L) {
//                    throw new IllegalMonitorStateException();
//                }
//                if (nanos < SPIN_FOR_TIMEOUT_THRESHOLD) {
//                    nanos = SPIN_FOR_TIMEOUT_THRESHOLD;
//                }
//                LockSupport.parkNanos(this, nanos);
//                if (Thread.interrupted()) {
//                    throw new InterruptedException();
//                }
//            }
//        }
//    }
//
//    private long newState(final long word, final int bit1, final int bit2, final int state) {
//        long result = word;
//        switch (state) {
//            case STATE_NOT_IN_USE:
//                result = clear(word, bit1);
//                result = clear(word, bit2);
//                break;
//            case STATE_IN_USE:
//                result = clear(word, bit1);
//                result = set(word, bit2);
//                break;
//            case STATE_REMOVED:
//                result = set(word, bit1);
//                result = clear(word, bit2);
//                break;
//            case STATE_RESERVED:
//                result = set(word, bit1);
//                result = set(word, bit2);
//                break;
//            default:
//                throw new Error();
//        }
//        return result;
//    }
//
//    private boolean isNotInUse(final int index) {
//        return getState(index) == STATE_NOT_IN_USE;
//    }
//
//    private boolean isInUse(final int index) {
//        return getState(index) == STATE_IN_USE;
//    }
//
//    private boolean isRemoved(final int index) {
//        return getState(index) == STATE_REMOVED;
//    }
//
//    private boolean isReserved(final int index) {
//        return getState(index) == STATE_RESERVED;
//    }
//
//    private long set(final long word, final int bit) {
//        return (word | (1L << (bit & BITMASK)));
//    }
//
//    private long clear(final long word, final int bit) {
//        return (word & ~(1L << (bit & BITMASK)));
//    }
//
//    private static int wordIndex(int index) {
//        //return bitIndex >> ADDRESS_BITS_PER_WORD;
//        int slotIndex = index >> BITSHIFT;
////        long word = (long) AA.getVolatile(bits, slotIndex);
////        int bit = (index & BITMASK) << 1;
////        int bit1 = Math.toIntExact(word & (1 << (bit & BITMASK)));
////        int bit2 = Math.toIntExact(word & (1 << ((bit + 1) & BITMASK)));
////        return (bit1 << 1) | bit2;
//        return slotIndex;
//    }
//
//    public JdbcConnection nextState(int state) {
//        long word;
//        JdbcConnection e;
//        for (int l = states.length, l2, i = 0; i < l; i++) {
//            word = (long) AA.getVolatile(states, i);
//            l2 = (i == l - 1 ? 64 : ((l & 63) >> 2));
//            for (int s, bit = 0; bit < l2; bit = +2) {
//                if ((s = Math.toIntExact(0x3 & (word >> bit))) == state && (e = getPoolEntry(bit >> 1)) != null && e.getState() == state) {
//                    return e;
//                }
//            }
//        }
//        return null;
//    }
}
