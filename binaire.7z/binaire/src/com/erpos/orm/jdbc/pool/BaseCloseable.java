package com.erpos.orm.jdbc.pool;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.sql.SQLException;

public abstract class BaseCloseable {

    private volatile int closed;

    public final boolean isClosed() {
        return closed != 0;
    }

    protected final void checkClosed() throws SQLException {
        if (isClosed()) {
            throw new SQLException("Connection is closed");
        }
    }

    protected void beforeClose() throws SQLException {

    }

    protected abstract void doClose() throws SQLException;

    public final void close() throws SQLException {
        beforeClose();
        int c;
        while ((c = closed) == 0 && compareAndSetClosed(false, true)) {
            doClose();
            break;
        }
    }

    protected final boolean compareAndSetClosed(boolean expectedValue, boolean newValue) {
        return CLOSED.compareAndSet(this, (expectedValue ? 1 : 0), (newValue ? 1 : 0));
    }

    private static final VarHandle CLOSED;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            CLOSED = l.findVarHandle(BaseCloseable.class, "closed", int.class);
        } catch (ReflectiveOperationException e) {
            throw new Error(e);
        }
    }
}
