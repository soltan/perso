package com.erpos.orm.jdbc.pool.management;

public interface JdbcConfigMXBean {

    String getPoolName();

    String getCatalog();

    String getSchema();

    String getDriverClassName();

    String getJdbcUrl();

    String getUsername();

    void setUsername(String username);

    void setPassword(String password);

    long getConnectionTimeout();

    void setConnectionTimeout(long connectionTimeoutMs);

    long getValidationTimeout();

    void setValidationTimeout(long validationTimeoutMs);

    long getIdleTimeout();

    void setIdleTimeout(long idleTimeoutMs);
//
//    long getLeakDetectionThreshold();
//
//    void setLeakDetectionThreshold(long leakDetectionThresholdMs);
//
    long getMaxLifetime();

    void setMaxLifetime(long maxLifetimeMs);

    int getMinimumIdle();

    void setMinimumIdle(int minimumIdle);

    int getMaximumPoolSize();

    void setMaximumPoolSize(int maxPoolSize);

}
