package com.erpos.orm.jdbc.pool;

import com.erpos.log.Logger;
import com.erpos.log.LoggerFactory;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.sql.*;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Executor;

import static com.erpos.common.util.ClockSource.currentTime;
import static com.erpos.common.util.ClockSource.elapsedDisplayString;

public final class JdbcConnection extends BaseCloseable implements Connection {

    static final int DIRTY_BIT_READONLY = 0b000001;
    static final int DIRTY_BIT_AUTOCOMMIT = 0b000010;
    static final int DIRTY_BIT_ISOLATION = 0b000100;
    static final int DIRTY_BIT_CATALOG = 0b001000;
    static final int DIRTY_BIT_NETTIMEOUT = 0b010000;
    static final int DIRTY_BIT_SCHEMA = 0b100000;

    static final int STATE_NOT_IN_USE = 0;
    static final int STATE_IN_USE = 1;
    static final int STATE_REMOVED = 2;
    static final int STATE_RESERVED = 3;
    static final int STATE_EVICTED = 3;

    private static final Logger LOGGER;
    private static final Set<String> ERROR_STATES;
    private static final Set<Integer> ERROR_CODES;

    static {
        LOGGER = LoggerFactory.getLogger(JdbcConnection.class);
        ERROR_STATES = Set.of(
                "0A000",// FEATURE UNSUPPORTED
                "57P01",// ADMIN SHUTDOWN
                "57P02",// CRASH SHUTDOWN
                "57P03",// CANNOT CONNECT NOW
                "01002",// SQL92 disconnect error
                "JZ0C0",// Sybase disconnect error
                "JZ0C1"); // Sybase disconnect error
        ERROR_CODES = Set.of(500150, 2399);
    }

    private volatile int dirtyBits;
    private boolean isCommitStateDirty;

    private int networkTimeout;
    private int transactionIsolation;
    private String dbcatalog;
    private String dbschema;

    //    private volatile ScheduledFuture<?> endOfLife;
    private final JdbcPool jdbcPool;
    private final Connection physicalConnection;
    private boolean isReadOnly;
    private boolean isAutoCommit;
    private volatile long lastAccessed;
    private volatile int state = 0;

    private JdbcConnection(final JdbcPool pool, final Connection physicalConnection, final long createdAccess, final boolean isReadOnly, final boolean isAutoCommit) {
        this.jdbcPool = pool;
        this.physicalConnection = physicalConnection;
        this.isReadOnly = isReadOnly;
        this.isAutoCommit = isAutoCommit;
        this.lastAccessed = createdAccess;
    }
//
//    static JdbcConnection of(final JdbcPool pool, final Connection connection, final boolean isReadOnly, final boolean isAutoCommit) {
//        return of(pool, connection, Instant.now().toEpochMilli(), isReadOnly, isAutoCommit);
//    }

    static JdbcConnection of(final JdbcPool pool, final Connection connection, final long createdAccess, final boolean isReadOnly, final boolean isAutoCommit) {
        return new JdbcConnection(pool, connection, createdAccess, isReadOnly, isAutoCommit);
    }

    public Connection getPhysicalConnection() {
        return physicalConnection;
    }

    @Override
    public Statement createStatement() throws SQLException {
        checkClosed();
        try {
            return JdbcStatement.of(this, physicalConnection.createStatement());
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public CallableStatement prepareCall(String sql) throws SQLException {
        checkClosed();
        try {
            return JdbcCallableStatement.of(this, physicalConnection.prepareCall(sql));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String nativeSQL(String sql) throws SQLException {
        checkClosed();
        try {
            return physicalConnection.nativeSQL(sql);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setAutoCommit(autoCommit);
            isAutoCommit = autoCommit;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_AUTOCOMMIT);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getAutoCommit();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void commit() throws SQLException {
        checkClosed();
        try {
            physicalConnection.commit();
            isCommitStateDirty = false;
            ////lastAccess = currentTime();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void rollback() throws SQLException {
        checkClosed();
        try {
            physicalConnection.rollback();
            isCommitStateDirty = false;
            ////lastAccess = currentTime();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    protected void beforeClose() {
        ////closeStatements();
    }

    @Override
    public void doClose() throws SQLException {
        try {
            if (isCommitStateDirty && !isAutoCommit) {
                physicalConnection.rollback();
                lastAccessed = currentTime();
                LOGGER.debug("{} - Executed rollback on connection {} due to dirty commit state on close().", jdbcPool.getPoolName(), physicalConnection);
            }
            if (dirtyBits != 0) {
                resetConnectionState(this, dirtyBits);
                lastAccessed = currentTime();
            }
            physicalConnection.clearWarnings();
        } catch (SQLException e) {
            // when connections are aborted, exceptions are often thrown that should not reach the application
            if (!isMarkedEvicted()) {
                throw checkException(e);
            }
        } finally {
            recycle(lastAccessed);
        }
    }

    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        checkClosed();
        try {
            markCommitStateDirty();
            return physicalConnection.getMetaData();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setReadOnly(boolean readOnly) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setReadOnly(readOnly);
            isReadOnly = readOnly;
            isCommitStateDirty = false;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_READONLY);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.isReadOnly();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCatalog(String catalog) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setCatalog(catalog);
            dbcatalog = catalog;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_CATALOG);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getCatalog() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getCatalog();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTransactionIsolation(int level) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setTransactionIsolation(level);
            transactionIsolation = level;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_ISOLATION);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getTransactionIsolation();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getWarnings();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        checkClosed();
        try {
            physicalConnection.clearWarnings();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
        checkClosed();
        try {
            return JdbcStatement.of(this, physicalConnection.createStatement(resultSetType, resultSetConcurrency));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql, resultSetType, resultSetConcurrency));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
        checkClosed();
        try {
            return JdbcCallableStatement.of(this, physicalConnection.prepareCall(sql, resultSetType, resultSetConcurrency));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Map<String, Class<?>> getTypeMap() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getTypeMap();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setTypeMap(map);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setHoldability(int holdability) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setHoldability(holdability);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getHoldability() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getHoldability();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Savepoint setSavepoint() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.setSavepoint();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Savepoint setSavepoint(String name) throws SQLException {
        checkClosed();
        try {
            return physicalConnection.setSavepoint(name);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void rollback(Savepoint savepoint) throws SQLException {
        checkClosed();
        try {
            physicalConnection.rollback(savepoint);
            isCommitStateDirty = false;
            lastAccessed = currentTime();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        checkClosed();
        try {
            physicalConnection.releaseSavepoint(savepoint);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        checkClosed();
        try {
            return JdbcStatement.of(this, physicalConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        checkClosed();
        try {
            return JdbcCallableStatement.of(this, physicalConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql, autoGeneratedKeys));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql, columnIndexes));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
        checkClosed();
        try {
            return JdbcPreparedStatement.of(this, physicalConnection.prepareStatement(sql, columnNames));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Clob createClob() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createClob();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Blob createBlob() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createBlob();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public NClob createNClob() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createNClob();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createSQLXML();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean isValid(int timeout) throws SQLException {
        if (isClosed()) {
            return false;
        }
        try {
            return physicalConnection.isValid(timeout);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    //TODO - delete checkException for no thows SQLException
    @Override
    public void setClientInfo(String name, String value) throws SQLClientInfoException {
        try {
            checkClosed();
            physicalConnection.setClientInfo(name, value);
        } catch (SQLClientInfoException e) {
            throw checkException(e);
        } catch (SQLException e) {
            SQLClientInfoException scie = new SQLClientInfoException();
            scie.setNextException(e);
            throw checkException(scie);
        }
    }

    @Override
    public void setClientInfo(Properties properties) throws SQLClientInfoException {
        try {
            checkClosed();
            physicalConnection.setClientInfo(properties);
        } catch (SQLClientInfoException e) {
            throw checkException(e);
        } catch (SQLException e) {
            SQLClientInfoException scie = new SQLClientInfoException();
            scie.setNextException(e);
            throw checkException(scie);
        }
    }

    @Override
    public String getClientInfo(String name) throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getClientInfo(name);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getClientInfo();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createArrayOf(typeName, elements);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
        checkClosed();
        try {
            return physicalConnection.createStruct(typeName, attributes);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setSchema(String schema) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setSchema(schema);
            this.dbschema = schema;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_SCHEMA);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getSchema() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getSchema();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void abort(Executor executor) throws SQLException {
        if (!isClosed()) {
            try {
                physicalConnection.abort(executor);
            } catch (SQLException e) {
                throw checkException(e);
            }
        }
    }

    @Override
    public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
        checkClosed();
        try {
            physicalConnection.setNetworkTimeout(executor, milliseconds);
            networkTimeout = milliseconds;
            DIRTYBITS.getAndBitwiseOr(this, DIRTY_BIT_NETTIMEOUT);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getNetworkTimeout() throws SQLException {
        checkClosed();
        try {
            return physicalConnection.getNetworkTimeout();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void beginRequest() throws SQLException {
        checkClosed();
        try {
            physicalConnection.beginRequest();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void endRequest() throws SQLException {
        checkClosed();
        try {
            physicalConnection.endRequest();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean setShardingKeyIfValid(ShardingKey shardingKey,
                                         ShardingKey superShardingKey, int timeout)
            throws SQLException {
        checkClosed();
        try {
            return physicalConnection.setShardingKeyIfValid(shardingKey, superShardingKey, timeout);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean setShardingKeyIfValid(ShardingKey shardingKey, int timeout)
            throws SQLException {
        checkClosed();
        try {
            return physicalConnection.setShardingKeyIfValid(shardingKey, timeout);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setShardingKey(ShardingKey shardingKey, ShardingKey superShardingKey)
            throws SQLException {
        checkClosed();
        try {
            physicalConnection.setShardingKey(shardingKey, superShardingKey);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setShardingKey(ShardingKey shardingKey)
            throws SQLException {
        checkClosed();
        try {
            physicalConnection.setShardingKey(shardingKey);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        checkClosed();
        try {
            if (iface.isInstance(physicalConnection)) {
                return iface.cast(physicalConnection);
            } else if (physicalConnection instanceof Wrapper) {
                return physicalConnection.unwrap(iface);
            }
            throw new SQLException("Wrapped connection is not an instance of " + iface);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        checkClosed();
        try {
            return iface.isInstance(physicalConnection) || (physicalConnection instanceof Wrapper && physicalConnection.isWrapperFor(iface));
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    //@Override
    public final <E extends SQLException> E checkException(final E sqle) {
        SQLException nse = sqle;
        int isClosed = 1;
        for (int depth = 0; !isClosed() && nse != null && depth < 10; depth++) {
            final String sqlState = nse.getSQLState();
            if (sqlState != null && sqlState.startsWith("08") || ERROR_STATES.contains(sqlState) || ERROR_CODES.contains(nse.getErrorCode())) {
                // broken connection
                LOGGER.warn("{} - Connection {} marked as broken because of SQLSTATE({}), ErrorCode({})",
                        jdbcPool.getPoolName(), physicalConnection, sqlState, nse.getErrorCode(), nse);
                evict("(connection is broken)");
                compareAndSetClosed(false, true);
            } else {
                nse = nse.getNextException();
            }
        }
        return sqle;
    }

    @Override
    public final String toString() {
        String sb = this.getClass().getSimpleName() + '@' + System.identityHashCode(this);
        if (!isClosed()) {
            sb += " wrapping " + physicalConnection;
        }
        final long now = currentTime();
        return sb + ", accessed " + elapsedDisplayString(lastAccessed, now) + " ago, " + stateToString();
    }

    private String stateToString() {
        switch (state) {
            case STATE_IN_USE:
                return "IN_USE";
            case STATE_NOT_IN_USE:
                return "NOT_IN_USE";
            case STATE_REMOVED:
                return "REMOVED";
            case STATE_RESERVED:
                return "RESERVED";
            default:
                return "Invalid";
        }
    }

    //
//    //
////
////    // ***********************************************************************
////    //                     Connection State Accessors
////    // ***********************************************************************
////
////    final boolean getAutoCommitState() {
////        return isAutoCommit;
////    }
////
////    final String getCatalogState() {
////        return dbcatalog;
////    }
////
////    final String getSchemaState() {
////        return dbschema;
////    }
////
////    final int getTransactionIsolationState() {
////        return transactionIsolation;
////    }
////
////    final boolean getReadOnlyState() {
////        return isReadOnly;
////    }
////
////    final int getNetworkTimeoutState() {
////        return networkTimeout;
////    }
////
////    // **********************************************************************
////    //                         Private classes
////    // **********************************************************************
////
////    private final long currentTime() {
////        return Instant.now().toEpochMilli();
////    }
////
    final void markCommitStateDirty() {
        if (isAutoCommit) {
            this.lastAccessed = currentTime();
        } else {
            isCommitStateDirty = true;
        }
    }

    void recycle(final long lastAccessed) {
        if (physicalConnection != null) {
            this.lastAccessed = lastAccessed;
            jdbcPool.recycle(this);
        }
    }

    //
//    void setFutureEol(final ScheduledFuture<?> endOfLife) {
//        this.endOfLife = endOfLife;
//    }
//
//    //    Connection createProxyConnection(final long now)
////    {
////        return JdbcConnection.of(jdbcPool,this, openStatements, now, isReadOnly, isAutoCommit);
////    }
////
    void resetConnectionState(final JdbcConnection jdbcConnection, final int dirtyBits) throws SQLException {
        ////jdbcPool.resetConnectionState(physicalConnection, jdbcConnection, dirtyBits);
    }

    //
//    //    String getPoolName()
////    {
////        return jdbcPool.toString();
////    }
////
    boolean isMarkedEvicted() {
        return state == STATE_EVICTED;
    }

    //
//    void markEvicted() {
//        this.evict = true;
//    }
//
    void evict(final String closureReason) {
        jdbcPool.closeConnection(this, closureReason);
    }

    //
////    long getMillisSinceBorrowed()
////    {
////        return ClockSource.elapsedMillis(lastBorrowed);
////    }
////
//
//    Connection closeEntry() {
//        ScheduledFuture<?> eol = endOfLife;
//        if (eol != null && !eol.isDone() && !eol.cancel(false)) {
//            LOGGER.warn("{} - maxLifeTime expiration task cancellation unexpectedly returned false for connection {}", jdbcPool.getPoolName(), this);
//        }
//        Connection con = this;//connection;
//        //connection = null;
//        endOfLife = null;
//        return con;
//    }
//
    public int getState() {
        return state;
    }

    public void setState(int state) {
        long cur;
        do {
            cur = this.state;
        } while (cur != state && !STATE.compareAndSet(this, cur, state));
    }


    public boolean compareAndSet(int expect, int update) {
        return STATE.compareAndSet(this, expect, update);
    }

    public long getLastAccessed() {
        return lastAccessed;
    }

    public void setLastAccessed(long lastAccessed) {
        long cur;
        do {
            cur = this.lastAccessed;
        } while (cur != lastAccessed && !LASTACCESS.compareAndSet(this, cur, lastAccessed));
    }

    private static final VarHandle STATE;
    private static final VarHandle LASTACCESS;
    private static final VarHandle DIRTYBITS;
    private static final VarHandle DBCATALOG;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            STATE = l.findVarHandle(JdbcConnection.class, "state", long.class);
            LASTACCESS = l.findVarHandle(JdbcConnection.class, "lastAccess", long.class);
            DIRTYBITS = l.findVarHandle(JdbcConnection.class, "dirtyBits", int.class);
            DBCATALOG = l.findVarHandle(JdbcConnection.class, "dbcatalog", String.class);
        } catch (ReflectiveOperationException e) {
            throw new Error(e);
        }
    }
}
