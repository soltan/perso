//package com.erpos.orm.jdbc.pool;
//
//import java.io.Closeable;
//import java.sql.Connection;
//
//public class LogicalConnection implements Closeable {
//
//    @Override
//    public void close() {
//
//    }
//
//    public boolean compareAndSet(int stateNotInUse, int stateInUse) {
//        return false;
//    }
//
//    public Connection getPhysicalConnectiton() {
//        return null;
//    }
//
//    public long getLastAccessed() {
//        return 0;
//    }
//
//    public void setLastAccessed(long now) {
//    }
//
//    public boolean isMarkedEvicted() {
//        return false;
//    }
//}
