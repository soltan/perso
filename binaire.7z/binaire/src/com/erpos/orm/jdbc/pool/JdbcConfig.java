package com.erpos.orm.jdbc.pool;

import com.erpos.common.util.PropertiesReader;
import com.erpos.log.Logger;
import com.erpos.log.LoggerFactory;
import com.erpos.orm.jdbc.pool.management.JdbcConfigMXBean;
import com.erpos.orm.transaction.TransactionIsolation;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

public class JdbcConfig implements JdbcConfigMXBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(JdbcConfig.class);
    private static final int NCPU = Runtime.getRuntime().availableProcessors();

    private static final char[] ID_CHARACTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    private static final long DEFAULT_MAX_LIFETIME = MINUTES.toMillis(30);
    private static final long DEFAULT_CONNECTION_TIMEOUT = SECONDS.toMillis(30);
    private static final long DEFAULT_VALIDATION_TIMEOUT = SECONDS.toMillis(5);
    private static final long DEFAULT_IDLE_TIMEOUT = MINUTES.toMillis(10);
    private static final int DEFAULT_MIN_POOL_SIZE = (NCPU * 2) + 1;
    private static final int DEFAULT_MAX_POOL_SIZE = (DEFAULT_MIN_POOL_SIZE << 1);
    //
    // Properties NOT changeable at runtime
    private final String poolName;
    private final String catalog;
    private final String schema;
    private final String driverClassName;
    private final String jdbcUrl;
    private final int transactionIsolation;
    private final boolean isAutoCommit;
    private final boolean isReadOnly;
    private final boolean isRegisterMbeans;
    //    private final boolean isIsolateInternalQueries;
//    private final boolean isAllowPoolSuspension;
//    private final boolean isQueryTimeoutSupported;
    //    private final String connectionInitSql;
//    private final long initializationFailTimeout;
//
//    //private final DataSource dataSource;
//    //private final final Properties dataSourceProperties;
//
    // Properties changeable at runtime through the JdbcConfigMXBean
    private volatile String username;
    private volatile String password;
    private volatile long maxLifetime;
    private volatile long connectionTimeout;
    private volatile long validationTimeout;
    private volatile long idleTimeout;
    //    private volatile long leakDetectionThreshold;
    private volatile int maxPoolSize;
    private volatile int minimumIdle;

    //    private volatile boolean sealed;
//
    public JdbcConfig(PropertiesReader properties) {
        // Properties NOT changeable at runtime
        this.poolName = properties.getString("dataSource.poolName", generatePoolName());
        this.catalog = getNullIfEmpty(properties, "dataSource.catalog");
        this.schema = required(properties, "dataSource.schema");
        this.driverClassName = required(properties, "dataSource.driverClassName");
        this.jdbcUrl = required(properties, "dataSource.jdbcUrl");
        this.transactionIsolation = checkTransactionIsolation(properties.getString("dataSource.transactionIsolationName"));
        this.isAutoCommit = properties.getBoolean("dataSource.isAutoCommit");
        this.isReadOnly = properties.getBoolean("dataSource.isReadOnly");
        this.isRegisterMbeans = properties.getBoolean("dataSource.isRegisterMbeans");
////        dataSourceProperties = new Properties();
////        healthCheckProperties = new Properties();
//        this.initializationFailTimeout = properties.getOrDefault("dataSource.initializationFailTimeout", 1);
//        this.connectionInitSql = properties.getOrDefault("dataSource.connectionInitSql", null);
//        this.isIsolateInternalQueries = properties.getOrDefault("dataSource.isIsolateInternalQueries", false);
//        this.isAllowPoolSuspension = properties.getOrDefault("dataSource.isAllowPoolSuspension", false);
//        this.isQueryTimeoutSupported = properties.getOrDefault("dataSource.isQueryTimeoutSupported", false);
//        this.validate();


        // Properties changeable at runtime
        this.setUsername(properties.getString("dataSource.username", null));
        this.setPassword(properties.getString("dataSource.password", null));
        this.setMaxLifetime(properties.getLong("dataSource.maxLifetime", DEFAULT_MAX_LIFETIME));
        this.setConnectionTimeout(properties.getLong("dataSource.connectionTimeout", DEFAULT_CONNECTION_TIMEOUT));
        this.setValidationTimeout(properties.getLong("dataSource.validationTimeout", DEFAULT_VALIDATION_TIMEOUT));
        this.setIdleTimeout(properties.getLong("dataSource.idleTimeout", DEFAULT_IDLE_TIMEOUT));
        this.setMaximumPoolSize(properties.getInteger("dataSource.maxPoolSize", DEFAULT_MAX_POOL_SIZE));
        this.setMinimumIdle(properties.getInteger("dataSource.minimumIdle", DEFAULT_MIN_POOL_SIZE));
//        this.setLeakDetectionThreshold(properties.getOrDefault("dataSource.leakDetectionThreshold", null));
        if (isRegisterMbeans && poolName.contains(":")) {
            throw new IllegalArgumentException("poolName cannot contain ':' when used with JMX");
        }
    }

    private final String required(PropertiesReader properties, String prop) {
        String value = properties.getString(prop);
        if (value == null || (value = value.trim()).isEmpty()) {
            final String msg = String.format("Pool %s: %s property is required", this.poolName, prop);
            LOGGER.error(msg);
            throw new IllegalArgumentException(msg);
        }
        return value;
    }

    private final String getNullIfEmpty(PropertiesReader properties, String prop) {
        String value = properties.getString(prop);
        if (value != null && (value = value.trim()).isEmpty()) {
            return null;
        }
        return value;
    }

    @Override
    public String getPoolName() {
        return poolName;
    }

    @Override
    public String getCatalog() {
        return catalog;
    }

    @Override
    public String getSchema() {
        return schema;
    }

    @Override
    public String getDriverClassName() {
        return driverClassName;
    }

    @Override
    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public int getTransactionIsolation() {
        return transactionIsolation;
    }

    public boolean isAutoCommit() {
        return isAutoCommit;
    }

    public boolean isReadOnly() {
        return isReadOnly;
    }

    public boolean isRegisterMbeans() {
        return isRegisterMbeans;
    }
//
//    public boolean isAllowPoolSuspension() {
//        return isAllowPoolSuspension;
//    }
//
//    public boolean isQueryTimeoutSupported() {
//        return isQueryTimeoutSupported;
//    }
//
//    public long getInitializationFailTimeout() {
//        return initializationFailTimeout;
//    }
//
//    public boolean isIsolateInternalQueries() {
//        return isIsolateInternalQueries;
//    }
//
//
    //    @Override
//    public long getLeakDetectionThreshold() {
//        return leakDetectionThreshold;
//    }
//
//    @Override
//    public void setLeakDetectionThreshold(long leakDetectionThresholdMs) {
//        this.leakDetectionThreshold = leakDetectionThresholdMs;
//    }
//
//
    @Override
    public String getUsername() {
        return username;
    }


    @Override
    public void setUsername(String username) {
        String v = this.username;
        while (!USERNAME.compareAndSet(this, v, username)) {
            v = this.username;
        }
    }

    public String getPassword() {
        return password;
    }

    @Override
    public void setPassword(String password) {
        String v = this.password;
        while (!PASSWORD.compareAndSet(this, v, password)) {
            v = this.password;
        }
    }

    @Override
    public long getMaxLifetime() {
        return maxLifetime;
    }

    @Override
    public void setMaxLifetime(long maxLifetimeMs) {
        if (maxLifetimeMs != 0 && maxLifetimeMs < SECONDS.toMillis(30)) {
            LOGGER.warn("{} - maxLifetime is less than 30000ms, setting to default {}ms.", poolName, MAX_LIFETIME);
            maxLifetimeMs = DEFAULT_MAX_LIFETIME;
        }
        long v = this.maxLifetime;
        while (!MAX_LIFETIME.compareAndSet(this, v, maxLifetimeMs)) {
            v = this.maxLifetime;
        }
    }

    @Override
    public long getConnectionTimeout() {
        return connectionTimeout;
    }

    @Override
    public void setConnectionTimeout(long connectionTimeoutMs) {
        if (connectionTimeoutMs == 0) {
            connectionTimeoutMs = Integer.MAX_VALUE;
        } else if (connectionTimeoutMs < 250) {
            LOGGER.error("{} - connectionTimeout is less than 250ms", poolName);
            throw new IllegalArgumentException("connectionTimeout cannot be less than 250ms");
        }
        long v = this.connectionTimeout;
        while (!CONNECTION_TIMEOUT.compareAndSet(this, v, connectionTimeoutMs)) {
            v = this.connectionTimeout;
        }
    }

    @Override
    public long getValidationTimeout() {
        return validationTimeout;
    }


    @Override
    public void setValidationTimeout(long validationTimeoutMs) {
        if (validationTimeoutMs < 250) {
            LOGGER.error("{} - validationTimeoutMs is less than 250ms", poolName);
            throw new IllegalArgumentException("validationTimeoutMs cannot be less than 250ms");
        }
        long v = this.validationTimeout;
        while (!VALIDATION_TIMEOUT.compareAndSet(this, v, validationTimeoutMs)) {
            v = this.validationTimeout;
        }
    }

    @Override
    public long getIdleTimeout() {
        return idleTimeout;
    }

    @Override
    public void setIdleTimeout(long idleTimeoutMs) {
        if (idleTimeoutMs < 0) {
            throw new IllegalArgumentException("idleTimeout cannot be negative");
        }
        if (idleTimeoutMs + SECONDS.toMillis(1) > maxLifetime && maxLifetime > 0) {
            LOGGER.warn("{} - idleTimeout is close to or more than maxLifetime, disabling it.", poolName);
            idleTimeoutMs = 0;
        }
        if (idleTimeoutMs != 0 && idleTimeoutMs < SECONDS.toMillis(10)) {
            LOGGER.warn("{} - idleTimeout is less than 10000ms, setting to default {}ms.", poolName, IDLE_TIMEOUT);
            idleTimeoutMs = DEFAULT_IDLE_TIMEOUT;
        }
        long v = this.idleTimeout;
        while (!IDLE_TIMEOUT.compareAndSet(this, v, idleTimeoutMs)) {
            v = this.idleTimeout;
        }
    }

    //    private void validateNumerics() {
//        if (leakDetectionThreshold > 0 /* && !unitTest*/) {
//            if (leakDetectionThreshold < SECONDS.toMillis(2) || (leakDetectionThreshold > maxLifetime && maxLifetime > 0)) {
//                LOGGER.warn("{} - leakDetectionThreshold is less than 2000ms or more than maxLifetime, disabling it.", poolName);
//                leakDetectionThreshold = 0;
//            }
//    }

    @Override
    public int getMaximumPoolSize() {
        return maxPoolSize;
    }

    @Override
    public void setMaximumPoolSize(int maxPoolSize) {
        if (maxPoolSize < 1) {
            LOGGER.warn("{} - maxPoolSize is less than 0", poolName);
            throw new IllegalArgumentException("maxPoolSize cannot be greater than min pool size");
        }
        if (maxPoolSize < minimumIdle) {
            LOGGER.warn("maxPoolSize cannot be greater than min pool size", poolName);
            throw new IllegalArgumentException("maxPoolSize cannot be greater than min pool size");
        }
        long v = this.maxPoolSize;
        while (!MAX_POOL_SIZE.compareAndSet(this, v, maxPoolSize)) {
            v = this.maxPoolSize;
        }
    }

    @Override
    public int getMinimumIdle() {
        return minimumIdle;
    }

    @Override
    public void setMinimumIdle(int minimumIdle) {
        if (minimumIdle < 1) {
            LOGGER.warn("{} - minimumIdle cannot be less than 1", poolName);
            throw new IllegalArgumentException("minimumIdle cannot be less than 1");
        }
        if (minimumIdle > maxPoolSize) {
            LOGGER.warn("{} - minPoolSize cannot be greater than max pool size", poolName);
            throw new IllegalArgumentException("minPoolSize cannot be greater than max pool size");
        }
        long v = this.minimumIdle;
        while (!MIN_IDLE.compareAndSet(this, v, minimumIdle)) {
            v = this.minimumIdle;
        }
    }

    //
//    public String getConnectionInitSql() {
//        return connectionInitSql;
//    }
//

    Properties getDataSourceProperties(){
        return null;
    }

    private int checkTransactionIsolation(String transactionIsolationName) {
        try {
            final String value;
            if (Objects.isNull(transactionIsolationName) || (value = transactionIsolationName.trim().toUpperCase(Locale.ROOT)).isEmpty()) {
                return TransactionIsolation.TRANSACTION_READ_COMMITTED.getTransactionIsolationState();
            }
            return TransactionIsolation.valueOf(value).getTransactionIsolationState();
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid transaction isolation value: " + transactionIsolationName);
        }
    }

    //
//
//
//    //    void seal() {
////        this.sealed = true;
////    }
////
////
////    public void copyStateTo(JdbcConfig other) {
////        for (Field field : JdbcConfig.class.getDeclaredFields()) {
////            if (!Modifier.isFinal(field.getModifiers())) {
////                field.setAccessible(true);
////                try {
////                    field.set(other, field.get(this));
////                } catch (Exception e) {
////                    throw new RuntimeException("Failed to copy HikariConfig state: " + e.getMessage(), e);
////                }
////            }
////        }
////
////        other.sealed = false;
////    }
////
    private String generatePoolName() {
        final ThreadLocalRandom random = ThreadLocalRandom.current();
        final String buf = "JdbcPool-" + IntStream.range(0, 4).mapToObj(i -> String.valueOf(ID_CHARACTERS[random.nextInt(62)])).collect(Collectors.joining());
        LOGGER.info("assigned random pool name '{}' (security manager prevented access to system properties)", buf);
        return buf.toString();
    }

    private final static VarHandle USERNAME;
    private final static VarHandle PASSWORD;
    private final static VarHandle MAX_LIFETIME;
    private final static VarHandle CONNECTION_TIMEOUT;
    private final static VarHandle VALIDATION_TIMEOUT;
    private final static VarHandle IDLE_TIMEOUT;
    private final static VarHandle MIN_IDLE;
    private final static VarHandle MAX_POOL_SIZE;

    //    private final static VarHandle LEAK_DETECTION_THRESHOLD;
//
    static {
        try {
            final MethodHandles.Lookup l = MethodHandles.lookup();
            USERNAME = l.findVarHandle(JdbcConfig.class, "username", String.class);
            PASSWORD = l.findVarHandle(JdbcConfig.class, "password", String.class);
            MAX_LIFETIME = l.findVarHandle(JdbcConfig.class, "maxLifetime", long.class);
            CONNECTION_TIMEOUT = l.findVarHandle(JdbcConfig.class, "connectionTimeout", long.class);
            VALIDATION_TIMEOUT = l.findVarHandle(JdbcConfig.class, "validationTimeout", long.class);
            IDLE_TIMEOUT = l.findVarHandle(JdbcConfig.class, "idleTimeout", long.class);
            MIN_IDLE = l.findVarHandle(JdbcConfig.class, "minIdle", int.class);
            MAX_POOL_SIZE = l.findVarHandle(JdbcConfig.class, "maxPoolSize", int.class);
//            LEAK_DETECTION_THRESHOLD = l.findVarHandle(JdbcConfig.class, "leakDetectionThreshold", long.class);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new Error(e);
        }
    }
}
