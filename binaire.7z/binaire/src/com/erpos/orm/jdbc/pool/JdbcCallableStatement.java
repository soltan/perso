package com.erpos.orm.jdbc.pool;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;

public final class JdbcCallableStatement extends JdbcPreparedStatement<CallableStatement> implements CallableStatement {

    private JdbcCallableStatement(JdbcConnection connection, CallableStatement statement) {
        super(connection, statement);
    }

    static JdbcCallableStatement of(JdbcConnection connection, CallableStatement statement) {
        return new JdbcCallableStatement(connection, statement);
    }

    @Override
    public boolean wasNull() throws SQLException {
        try {
            return delegate.wasNull();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getString(int columnIndex) throws SQLException {
        try {
            return delegate.getString(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean getBoolean(int columnIndex) throws SQLException {
        try {
            return delegate.getBoolean(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public byte getByte(int columnIndex) throws SQLException {
        try {
            return delegate.getByte(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public short getShort(int columnIndex) throws SQLException {
        try {
            return delegate.getShort(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getInt(int columnIndex) throws SQLException {
        try {
            return delegate.getInt(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public long getLong(int columnIndex) throws SQLException {
        try {
            return delegate.getLong(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public float getFloat(int columnIndex) throws SQLException {
        try {
            return delegate.getFloat(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public double getDouble(int columnIndex) throws SQLException {
        try {
            return delegate.getDouble(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Deprecated
    @Override
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        try {
            return delegate.getBigDecimal(columnIndex, scale);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public byte[] getBytes(int columnIndex) throws SQLException {
        try {
            return delegate.getBytes(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Date getDate(int columnIndex) throws SQLException {
        try {
            return delegate.getDate(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Time getTime(int columnIndex) throws SQLException {
        try {
            return delegate.getTime(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        try {
            return delegate.getTimestamp(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getString(String columnLabel) throws SQLException {
        try {
            return delegate.getString(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean getBoolean(String columnLabel) throws SQLException {
        try {
            return delegate.getBoolean(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public byte getByte(String columnLabel) throws SQLException {
        try {
            return delegate.getByte(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public short getShort(String columnLabel) throws SQLException {
        try {
            return delegate.getShort(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getInt(String columnLabel) throws SQLException {
        try {
            return delegate.getInt(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public long getLong(String columnLabel) throws SQLException {
        try {
            return delegate.getLong(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public float getFloat(String columnLabel) throws SQLException {
        try {
            return delegate.getFloat(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public double getDouble(String columnLabel) throws SQLException {
        try {
            return delegate.getDouble(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public byte[] getBytes(String columnLabel) throws SQLException {
        try {
            return delegate.getBytes(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Date getDate(String columnLabel) throws SQLException {
        try {
            return delegate.getDate(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Time getTime(String columnLabel) throws SQLException {
        try {
            return delegate.getTime(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Timestamp getTimestamp(String columnLabel) throws SQLException {
        try {
            return delegate.getTimestamp(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            return delegate.getWarnings();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            delegate.clearWarnings();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            return delegate.getMetaData();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Object getObject(int columnIndex) throws SQLException {
        try {
            return delegate.getObject(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Object getObject(String columnLabel) throws SQLException {
        try {
            return delegate.getObject(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Reader getCharacterStream(int columnIndex) throws SQLException {
        try {
            return delegate.getCharacterStream(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Reader getCharacterStream(String columnLabel) throws SQLException {
        try {
            return delegate.getCharacterStream(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        try {
            return delegate.getBigDecimal(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public BigDecimal getBigDecimal(String columnLabel) throws SQLException {
        try {
            return delegate.getBigDecimal(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setFetchDirection(int direction) throws SQLException {
        try {
            delegate.setFetchDirection(direction);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException {
        try {
            return delegate.getFetchDirection();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setFetchSize(int rows) throws SQLException {
        try {
            delegate.setFetchSize(rows);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public int getFetchSize() throws SQLException {
        try {
            return delegate.getFetchSize();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBoolean(int columnIndex, boolean x) throws SQLException {
        try {
            delegate.setBoolean(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setByte(int columnIndex, byte x) throws SQLException {
        try {
            delegate.setByte(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setShort(int columnIndex, short x) throws SQLException {
        try {
            delegate.setShort(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setInt(int columnIndex, int x) throws SQLException {
        try {
            delegate.setInt(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setLong(int columnIndex, long x) throws SQLException {
        try {
            delegate.setLong(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setFloat(int columnIndex, float x) throws SQLException {
        try {
            delegate.setFloat(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setDouble(int columnIndex, double x) throws SQLException {
        try {
            delegate.setDouble(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        try {
            delegate.setBigDecimal(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setString(int columnIndex, String x) throws SQLException {
        try {
            delegate.setString(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBytes(int columnIndex, byte[] x) throws SQLException {
        try {
            delegate.setBytes(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setDate(int columnIndex, Date x) throws SQLException {
        try {
            delegate.setDate(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTime(int columnIndex, Time x) throws SQLException {
        try {
            delegate.setTime(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTimestamp(int columnIndex, Timestamp x) throws SQLException {
        try {
            delegate.setTimestamp(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
        try {
            delegate.setAsciiStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
        try {
            delegate.setBinaryStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
        try {
            delegate.setCharacterStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(int columnIndex, Object x, int scaleOrLength) throws SQLException {
        try {
            delegate.setObject(columnIndex, x, scaleOrLength);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(int columnIndex, Object x) throws SQLException {
        try {
            delegate.setObject(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBoolean(String columnLabel, boolean x) throws SQLException {
        try {
            delegate.setBoolean(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setByte(String columnLabel, byte x) throws SQLException {
        try {
            delegate.setByte(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setShort(String columnLabel, short x) throws SQLException {
        try {
            delegate.setShort(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setInt(String columnLabel, int x) throws SQLException {
        try {
            delegate.setInt(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setLong(String columnLabel, long x) throws SQLException {
        try {
            delegate.setLong(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setFloat(String columnLabel, float x) throws SQLException {
        try {
            delegate.setFloat(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setDouble(String columnLabel, double x) throws SQLException {
        try {
            delegate.setDouble(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBigDecimal(String columnLabel, BigDecimal x) throws SQLException {
        try {
            delegate.setBigDecimal(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setString(String columnLabel, String x) throws SQLException {
        try {
            delegate.setString(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBytes(String columnLabel, byte[] x) throws SQLException {
        try {
            delegate.setBytes(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setDate(String columnLabel, Date x) throws SQLException {
        try {
            delegate.setDate(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTime(String columnLabel, Time x) throws SQLException {
        try {
            delegate.setTime(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setTimestamp(String columnLabel, Timestamp x) throws SQLException {
        try {
            delegate.setTimestamp(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(String columnLabel, InputStream x, int length) throws SQLException {
        try {
            delegate.setAsciiStream(columnLabel, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(String columnLabel, InputStream x, int length) throws SQLException {
        try {
            delegate.setAsciiStream(columnLabel, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {

    }

    @Override
    public void setCharacterStream(String columnLabel, Reader reader, int length) throws SQLException {
        try {
            delegate.setCharacterStream(columnLabel, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {

    }

    @Override
    public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {

    }

    @Override
    public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {

    }

    @Override
    public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {

    }

    @Override
    public void setObject(String columnLabel, Object x, int scaleOrLength) throws SQLException {
        try {
            delegate.setObject(columnLabel, x, scaleOrLength);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(String columnLabel, Object x) throws SQLException {
        try {
            delegate.setObject(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException {
        try {
            return delegate.getObject(columnIndex, map);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Ref getRef(int columnIndex) throws SQLException {
        try {
            return delegate.getRef(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Blob getBlob(int columnIndex) throws SQLException {
        try {
            return delegate.getBlob(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Clob getClob(int columnIndex) throws SQLException {
        try {
            return delegate.getClob(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Array getArray(int columnIndex) throws SQLException {
        try {
            return delegate.getArray(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Object getObject(String columnLabel, Map<String, Class<?>> map) throws SQLException {
        try {
            return delegate.getObject(columnLabel, map);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Ref getRef(String columnLabel) throws SQLException {
        try {
            return delegate.getRef(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Blob getBlob(String columnLabel) throws SQLException {
        try {
            return delegate.getBlob(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Clob getClob(String columnLabel) throws SQLException {
        try {
            return delegate.getClob(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Array getArray(String columnLabel) throws SQLException {
        try {
            return delegate.getArray(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Date getDate(int columnIndex, Calendar cal) throws SQLException {
        try {
            return delegate.getDate(columnIndex, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Date getDate(String columnLabel, Calendar cal) throws SQLException {
        try {
            return delegate.getDate(columnLabel, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Time getTime(int columnIndex, Calendar cal) throws SQLException {
        try {
            return delegate.getTime(columnIndex, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Time getTime(String columnLabel, Calendar cal) throws SQLException {
        try {
            return delegate.getTime(columnLabel, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
        try {
            return delegate.getTimestamp(columnIndex, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, int sqlType, String typeName) throws SQLException {

    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType) throws SQLException {

    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {

    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {

    }

    @Override
    public Timestamp getTimestamp(String columnLabel, Calendar cal) throws SQLException {
        try {
            return delegate.getTimestamp(columnLabel, cal);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public URL getURL(int columnIndex) throws SQLException {
        try {
            return delegate.getURL(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setURL(String parameterName, URL val) throws SQLException {

    }

    @Override
    public void setNull(String parameterName, int sqlType) throws SQLException {

    }

    @Override
    public URL getURL(String columnLabel) throws SQLException {
        try {
            return delegate.getURL(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setRef(int columnIndex, Ref x) throws SQLException {
        try {
            delegate.setRef(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(int columnIndex, Blob x) throws SQLException {
        try {
            delegate.setBlob(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(String columnLabel, Blob x) throws SQLException {
        try {
            delegate.setBlob(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(int columnIndex, Clob x) throws SQLException {
        try {
            delegate.setClob(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(String columnLabel, Clob x) throws SQLException {
        try {
            delegate.setClob(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setArray(int columnIndex, Array x) throws SQLException {
        try {
            delegate.setArray(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public RowId getRowId(int columnIndex) throws SQLException {
        try {
            return delegate.getRowId(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public RowId getRowId(String columnLabel) throws SQLException {
        try {
            return delegate.getRowId(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setRowId(int columnIndex, RowId x) throws SQLException {
        try {
            delegate.setRowId(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setRowId(String columnLabel, RowId x) throws SQLException {
        try {
            delegate.setRowId(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            return delegate.isClosed();
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNString(int columnIndex, String nString) throws SQLException {
        try {
            delegate.setNString(columnIndex, nString);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNString(String columnLabel, String nString) throws SQLException {
        try {
            delegate.setNString(columnLabel, nString);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(int columnIndex, NClob nClob) throws SQLException {
        try {
            delegate.setNClob(columnIndex, nClob);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(String columnLabel, NClob nClob) throws SQLException {
        try {
            delegate.setNClob(columnLabel, nClob);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public NClob getNClob(int columnIndex) throws SQLException {
        try {
            return delegate.getNClob(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public NClob getNClob(String columnLabel) throws SQLException {
        try {
            return delegate.getNClob(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public SQLXML getSQLXML(int columnIndex) throws SQLException {
        try {
            return delegate.getSQLXML(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public SQLXML getSQLXML(String columnLabel) throws SQLException {
        try {
            return delegate.getSQLXML(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
        try {
            delegate.setSQLXML(columnIndex, xmlObject);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
        try {
            delegate.setSQLXML(columnLabel, xmlObject);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getNString(int columnIndex) throws SQLException {
        try {
            return delegate.getNString(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public String getNString(String columnLabel) throws SQLException {
        try {
            return delegate.getNString(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Reader getNCharacterStream(int columnIndex) throws SQLException {
        try {
            return delegate.getNCharacterStream(columnIndex);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public Reader getNCharacterStream(String columnLabel) throws SQLException {
        try {
            return delegate.getNCharacterStream(columnLabel);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        try {
            delegate.setNCharacterStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        try {
            delegate.setNCharacterStream(columnLabel, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
        try {
            delegate.setAsciiStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
        try {
            delegate.setBinaryStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        try {
            delegate.setCharacterStream(columnIndex, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
        try {
            delegate.setAsciiStream(columnLabel, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
        try {
            delegate.setBinaryStream(columnLabel, x, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        try {
            delegate.setCharacterStream(columnLabel, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
        try {
            delegate.setBlob(columnIndex, inputStream, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
        try {
            delegate.setBlob(columnLabel, inputStream, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(int columnIndex, Reader reader, long length) throws SQLException {
        try {
            delegate.setClob(columnIndex, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(String columnLabel, Reader reader, long length) throws SQLException {
        try {
            delegate.setClob(columnLabel, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(int columnIndex, Reader reader, long length) throws SQLException {
        try {
            delegate.setNClob(columnIndex, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(String columnLabel, Reader reader, long length) throws SQLException {
        try {
            delegate.setNClob(columnLabel, reader, length);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNCharacterStream(int columnIndex, Reader x) throws SQLException {
        try {
            delegate.setNCharacterStream(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNCharacterStream(String columnLabel, Reader reader) throws SQLException {
        try {
            delegate.setNCharacterStream(columnLabel, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(int columnIndex, InputStream x) throws SQLException {
        try {
            delegate.setAsciiStream(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(int columnIndex, InputStream x) throws SQLException {
        try {
            delegate.setBinaryStream(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCharacterStream(int columnIndex, Reader x) throws SQLException {
        try {
            delegate.setCharacterStream(columnIndex, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setAsciiStream(String columnLabel, InputStream x) throws SQLException {
        try {
            delegate.setAsciiStream(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBinaryStream(String columnLabel, InputStream x) throws SQLException {
        try {
            delegate.setBinaryStream(columnLabel, x);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setCharacterStream(String columnLabel, Reader reader) throws SQLException {
        try {
            delegate.setCharacterStream(columnLabel, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(int columnIndex, InputStream inputStream) throws SQLException {
        try {
            delegate.setBlob(columnIndex, inputStream);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setBlob(String columnLabel, InputStream inputStream) throws SQLException {
        try {
            delegate.setBlob(columnLabel, inputStream);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(int columnIndex, Reader reader) throws SQLException {
        try {
            delegate.setClob(columnIndex, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setClob(String columnLabel, Reader reader) throws SQLException {
        try {
            delegate.setClob(columnLabel, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(int columnIndex, Reader reader) throws SQLException {
        try {
            delegate.setNClob(columnIndex, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setNClob(String columnLabel, Reader reader) throws SQLException {
        try {
            delegate.setNClob(columnLabel, reader);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        try {
            return delegate.getObject(columnIndex, type);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        try {
            return delegate.getObject(columnLabel, type);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        try {
            return delegate.isWrapperFor(iface);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
        try {
            delegate.setObject(columnIndex, x, targetSqlType, scaleOrLength);
        } catch (SQLException e) {
            throw checkException(e);
        }

    }

    @Override
    public void setObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
        try {
            delegate.setObject(columnLabel, x, targetSqlType, scaleOrLength);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(int columnIndex, Object x, SQLType targetSqlType) throws SQLException {
        try {
            delegate.setObject(columnIndex, x, targetSqlType);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void setObject(String columnLabel, Object x, SQLType targetSqlType) throws SQLException {
        try {
            delegate.setObject(columnLabel, x, targetSqlType);
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
        try {
            delegate.registerOutParameter(parameterIndex, sqlType) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
        try {
            delegate.registerOutParameter(parameterIndex, sqlType, scale) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType) throws SQLException {
        try {
            delegate.registerOutParameter(parameterIndex, sqlType) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale) throws SQLException {
        try {
            delegate.registerOutParameter(parameterIndex, sqlType, scale) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName) throws SQLException {
        try {
            delegate.registerOutParameter(parameterIndex, sqlType, typeName) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType) throws SQLException {
        try {
            delegate.registerOutParameter(parameterName, sqlType) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType, int scale) throws SQLException {
        try {
            delegate.registerOutParameter(parameterName, sqlType, scale) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType, String typeName) throws SQLException {
        try {
            delegate.registerOutParameter(parameterName, sqlType, typeName) ;
        } catch (SQLException e) {
            throw checkException(e);
        }
    }
}