package com.erpos.log;

public interface LoggerFactory {

    static Logger getLogger(String name) {
        return null;
    }

    static Logger getLogger(Class<?> clazz) {
        return null;
    }
}