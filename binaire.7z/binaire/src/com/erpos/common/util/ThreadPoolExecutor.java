package com.erpos.common.util;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.locks.ReentrantLock;

import static java.util.Objects.*;

public class ThreadPoolExecutor implements Executor {//extends AbstractExecutorService {
    //    private static final int COUNT_BITS = Integer.SIZE - 3;
//    private static final int COUNT_MASK = (1 << COUNT_BITS) - 1;
//
//    // runState is stored in the high-order bits
//    private static final int RUNNING = -1 << COUNT_BITS;
//    private static final int SHUTDOWN = 0 << COUNT_BITS;
//    private static final int STOP = 1 << COUNT_BITS;
//    private static final int TIDYING = 2 << COUNT_BITS;
//    private static final int TERMINATED = 3 << COUNT_BITS;
//
//    // Packing and unpacking ctl
//    private static int runStateOf(int c) {
//        return c & ~COUNT_MASK;
//    }
//
//    private static int workerCountOf(int c) {
//        return c & COUNT_MASK;
//    }
//
//    private static int ctlOf(int rs, int wc) {
//        return rs | wc;
//    }
//
//    private static boolean runStateLessThan(int c, int s) {
//        return c < s;
//    }
//
//    private static boolean runStateAtLeast(int c, int s) {
//        return c >= s;
//    }
//
//    private static boolean isRunning(int c) {
//        return c < SHUTDOWN;
//    }
//
//    private static final int CORE_POOL_SIZE = 1;
//
//    private boolean compareAndIncrementWorkerCount(int expect) {
//        return ctl.compareAndSet(expect, expect + 1);
//    }
//
//    private boolean compareAndDecrementWorkerCount(int expect) {
//        return ctl.compareAndSet(expect, expect - 1);
//    }
//
//    private void decrementWorkerCount() {
//        ctl.addAndGet(-1);
//    }
//
    private final AtomicInteger ctl = new AtomicInteger(0);//ctlOf(RUNNING, 0));
    private final BlockingQueue<Runnable> workQueue;
    //    private final ReentrantLock mainLock = new ReentrantLock();
    private final AtomicReference<Worker> worker = new AtomicReference<>();
    //    private final Condition termination = mainLock.newCondition();
//    private long completedTaskCount;
    private final ThreadFactory threadFactory;

    private volatile RejectedExecutionHandler handler;
    private volatile long keepAliveTime;
    //    private volatile boolean allowCoreThreadTimeOut;
//
    private static final RejectedExecutionHandler defaultHandler = new AbortPolicy();
//    private static final RuntimePermission shutdownPerm = new RuntimePermission("modifyThread");

    public ThreadPoolExecutor(int queueSize, long keepAliveTime, TimeUnit unit) {
        this(queueSize, keepAliveTime, unit, Executors.defaultThreadFactory(), defaultHandler);
    }

    public ThreadPoolExecutor(int queueSize, long keepAliveTime, TimeUnit unit, ThreadFactory threadFactory) {
        this(queueSize, keepAliveTime, unit, threadFactory, defaultHandler);
    }

    public ThreadPoolExecutor(int queueSize, long keepAliveTime, TimeUnit unit, RejectedExecutionHandler handler) {
        this(queueSize, keepAliveTime, unit, Executors.defaultThreadFactory(), handler);
    }

    public ThreadPoolExecutor(int queueSize, long keepAliveTime, TimeUnit unit, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
        if (queueSize < 0 || keepAliveTime < 0) {
            throw new IllegalArgumentException();
        }
        if (threadFactory == null || handler == null)
            throw new NullPointerException();
        this.workQueue = new LinkedBlockingQueue<>(queueSize);
        this.keepAliveTime = unit.toNanos(keepAliveTime);
        this.threadFactory = threadFactory;
        this.handler = handler;
    }

    private final class Worker implements Runnable {
        //        private static final long serialVersionUID = 6138294804551838833L;
        final Thread thread;
        Runnable firstTask;
        private volatile long state;
        private volatile long whead;
        private volatile long wtail;
        private transient Thread exclusiveOwnerThread;

        Worker(Runnable firstTask) {
            setState(-1L); // inhibit interrupts until runWorker
            this.firstTask = firstTask;
            this.thread = getThreadFactory().newThread(this);
        }

        protected final void setExclusiveOwnerThread(Thread thread) {
            exclusiveOwnerThread = thread;
        }

        protected final Thread getExclusiveOwnerThread() {
            return exclusiveOwnerThread;
        }

        @Override
        public void run() {
            runWorker(this);
        }

        protected final long getState() {
            return state;
        }

        protected final boolean compareAndSetState(long expect, long update) {
            return STATE.compareAndSet(this, expect, update);
        }

        protected final void setState(long newState) {
            // See JDK-8180620: Clarify VarHandle mixed-access subtleties
            STATE.setVolatile(this, newState);
        }

        public boolean tryLock() {
            if (compareAndSetState(0L, 1L)) {
                setExclusiveOwnerThread(Thread.currentThread());
                return true;
            }
            return false;
        }

        public void lock() {
            if (!tryLock()) {
                long h, t, next;
                do {
                    t = wtail;
                } while (!compareAndSetTail(t, (next = t + 1L)));
                if(acquireQueued(next)){
                    selfInterrupt();
                }
            }
        }

        final boolean acquireQueued(final long node) {
            boolean interrupted = false;
            try {
                for (long p; ; ) {
                    if ((p = node - 1) == whead && tryLock()) {
                        setHead(node);
                        return interrupted;
                    }
                    if (shouldParkAfterFailedAcquire(p, node)) {
                        interrupted |= parkAndCheckInterrupt();
                    }
                }
            } catch (Throwable t) {
                ////cancelAcquire(node);
                if (interrupted) {
                    selfInterrupt();
                }
                throw t;
            }
        }


        protected boolean tryUnlock() {
            setExclusiveOwnerThread(null);
            setState(0);
            return true;
        }

        public void unlock() {
            setExclusiveOwnerThread(null);
            setState(0);
        }

        public boolean isLocked() {
            return getState() != 0L;
        }

        void interruptIfStarted() {
            Thread t;
            if (getState() >= 0L && (t = thread) != null && !t.isInterrupted()) {
                try {
                    t.interrupt();
                } catch (SecurityException ignore) {
                }
            }
        }

        protected boolean tryRelease() {
            setExclusiveOwnerThread(null);
            setState(0);
            return true;
        }

        private final boolean compareAndSetTail(long expect, long update) {
            return WTAIL.compareAndSet(this, expect, update);
        }

        private final boolean parkAndCheckInterrupt() {
            ReentrantLock
            LockSupport.park(this);
            return Thread.interrupted();
        }

        private void setHead(long node) {
            WHEAD.setVolatile(node);
        }

    }

    static boolean shouldParkAfterFailedAcquire(long pred, long node) {
        return true;
    }

    static void selfInterrupt() {
        Thread.currentThread().interrupt();
    }

    //
//    private void advanceRunState(int targetState) {
//        // assert targetState == SHUTDOWN || targetState == STOP;
//        for (; ; ) {
//            int c = ctl.get();
//            if (runStateAtLeast(c, targetState) ||
//                    ctl.compareAndSet(c, ctlOf(targetState, workerCountOf(c))))
//                break;
//        }
//    }
//
//    private void checkShutdownAccess() {
//        // assert mainLock.isHeldByCurrentThread();
//        SecurityManager security = System.getSecurityManager();
//        if (security != null) {
//            security.checkPermission(shutdownPerm);
//            Worker w;
//            if ((w = worker.get()) != null) {
//                security.checkAccess(w.thread);
//            }
//        }
//    }
//
//    private void interruptWorkers() {
//        // assert mainLock.isHeldByCurrentThread();
//        Worker w;
//        if ((w = worker.get()) != null) {
//            w.interruptIfStarted();
//        }
//    }
//
//    private void interruptIdleWorkers() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            Worker w;
//            if ((w = worker.get()) != null) {
//                Thread t = w.thread;
//                if (!t.isInterrupted() && w.tryLock()) {
//                    try {
//                        t.interrupt();
//                    } catch (SecurityException ignore) {
//                    } finally {
//                        w.unlock();
//                    }
//                }
//            }
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    final void reject(Runnable command) {
//        handler.rejectedExecution(command, this);
//    }
//
//    void onShutdown() {
//    }
//
//    private List<Runnable> drainQueue() {
//        BlockingQueue<Runnable> q = workQueue;
//        ArrayList<Runnable> taskList = new ArrayList<>();
//        q.drainTo(taskList);
//        if (!q.isEmpty()) {
//            for (Runnable r : q.toArray(new Runnable[0])) {
//                if (q.remove(r))
//                    taskList.add(r);
//            }
//        }
//        return taskList;
//    }
//
//    private void processWorkerExit(Worker w, boolean completedAbruptly) {
//        if (completedAbruptly) // If abrupt, then workerCount wasn't adjusted
//            decrementWorkerCount();
//
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            completedTaskCount += w.completedTasks;
//            worker.compareAndSet(w, null);//TODO - workers.remove(w);
//        } finally {
//            mainLock.unlock();
//        }
//
//        tryTerminate();
//
//        int c = ctl.get();
//        if (runStateLessThan(c, STOP)) {
//            if (!completedAbruptly) {
//                int min = allowCoreThreadTimeOut ? 0 : CORE_POOL_SIZE;
//                if (min == 0 && !workQueue.isEmpty()) min = 1;
//                if (workerCountOf(c) >= min)
//                    return; // replacement not needed
//            }
//            addWorker(null);
//        }
//    }
//
    private Runnable getTask() {
        boolean timedOut = false; // Did the last poll() time out?
        for (int c; ; ) {
            // Check if queue empty only if necessary.
            if (runStateAtLeast(c = ctl.get(), SHUTDOWN) && (runStateAtLeast(c, STOP) || workQueue.isEmpty())) {
                decrementWorkerCount();
                return null;
            }
            int wc = workerCountOf(c);
            // Are workers subject to culling?
            boolean timed = allowCoreThreadTimeOut || wc > CORE_POOL_SIZE;
            if ((wc > CORE_POOL_SIZE || (timed && timedOut)) && (wc > 1 || workQueue.isEmpty())) {
                if (compareAndDecrementWorkerCount(c))
                    return null;
                continue;
            }
            try {
                Runnable r = timed ? workQueue.poll(keepAliveTime, TimeUnit.NANOSECONDS) : workQueue.take();
                if (r != null) {
                    return r;
                }
                timedOut = true;
            } catch (InterruptedException retry) {
                timedOut = false;
            }
        }
    }

    final void runWorker(Worker w) {
        Thread wt = Thread.currentThread();
        Runnable task = w.firstTask;
        w.firstTask = null;
        w.unlock(); // allow interrupts
        boolean completedAbruptly = true;
//        try {
//            while (task != null || (task = getTask()) != null) {
//                w.lock();
//                if ((runStateAtLeast(ctl.get(), STOP) || (Thread.interrupted() && runStateAtLeast(ctl.get(), STOP))) &&
//                        !wt.isInterrupted())
//                    wt.interrupt();
//                try {
//                    beforeExecute(wt, task);
//                    try {
//                        task.run();
//                        afterExecute(task, null);
//                    } catch (Throwable ex) {
//                        afterExecute(task, ex);
//                        throw ex;
//                    }
//                } finally {
//                    task = null;
//                    w.completedTasks++;
//                    w.unlock();
//                }
//            }
//            completedAbruptly = false;
//        } finally {
//            processWorkerExit(w, completedAbruptly);
//        }
    }

    @Override
    public void execute(Runnable command) {
        if (addWorker(requireNonNull(command))) {
            return;
        }
//        if (!isStopped() && workQueue.offer(command)) {
//            int recheck = ctl.get();
//            if (isStopped(recheck) && remove(command)) {
//                reject(command);
//            } else if (workerCountOf(recheck) == 0) {
//                addWorker(null);
//            }
//        } else if (!addWorker(command)) {
//            reject(command);
//        }
    }

    private boolean addWorker(Runnable firstTask) {
        Worker w = null, next = null;
        try {
            while (!isStopped() && isNull(w = worker.get()) && (nonNull(firstTask) || !workQueue.isEmpty())) {
                if (isNull(next)) {
                    next = new Worker(firstTask);
                }
                if (worker.compareAndSet(w, next)) {
                    final Thread t = next.thread;
                    if (nonNull(t)) {
                        if (t.isAlive()) {
                            throw new IllegalThreadStateException();
                        }
                        t.start();
                        return true;
                    } else {
                        break;
                    }
                }
            }
        } catch (Throwable th) {
            addWorkerFailed(w);
        }
        return false;
    }

    private void addWorkerFailed(Worker w) {
        if (nonNull(w)) {
            worker.compareAndSet(w, null);//TODO - workers.remove(w);
        }
        ////decrementWorkerCount();
        tryTerminate();
    }

    final void tryTerminate() {
//        for (int c; ; ) {
//            if (isRunning(c = ctl.get()) || runStateAtLeast(c, TIDYING) || (runStateLessThan(c, STOP) && !workQueue.isEmpty()))
//                return;
//            if (workerCountOf(c) != 0) { // Eligible to terminate
//                interruptIdleWorkers();
//                return;
//            }
//            final ReentrantLock mainLock = this.mainLock;
//            mainLock.lock();
//            try {
//                if (ctl.compareAndSet(c, ctlOf(TIDYING, 0))) {
//                    try {
//                        terminated();
//                    } finally {
//                        ctl.set(ctlOf(TERMINATED, 0));
//                        termination.signalAll();
//                    }
//                    return;
//                }
//            } finally {
//                mainLock.unlock();
//            }
//            // else retry on failed CAS
//        }
    }

    //
//
//    public void shutdown() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            checkShutdownAccess();
//            advanceRunState(SHUTDOWN);
//            interruptIdleWorkers();
//            onShutdown(); // hook for ScheduledThreadPoolExecutor
//        } finally {
//            mainLock.unlock();
//        }
//        tryTerminate();
//    }
//
//    public List<Runnable> shutdownNow() {
//        List<Runnable> tasks;
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            checkShutdownAccess();
//            advanceRunState(STOP);
//            interruptWorkers();
//            tasks = drainQueue();
//        } finally {
//            mainLock.unlock();
//        }
//        tryTerminate();
//        return tasks;
//    }
//
//    public boolean isShutdown() {
//        return runStateAtLeast(ctl.get(), SHUTDOWN);
//    }
//
    boolean isStopped() {
        return isStopped(ctl.get());
    }

    static boolean isStopped(int c) {
        return true;////runStateAtLeast(c, STOP);
    }

    //
//    public boolean isTerminating() {
//        int c = ctl.get();
//        return runStateAtLeast(c, SHUTDOWN) && runStateLessThan(c, TERMINATED);
//    }
//
//    public boolean isTerminated() {
//        return runStateAtLeast(ctl.get(), TERMINATED);
//    }
//
//    public boolean awaitTermination(long timeout, TimeUnit unit)
//            throws InterruptedException {
//        long nanos = unit.toNanos(timeout);
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            while (runStateLessThan(ctl.get(), TERMINATED)) {
//                if (nanos <= 0L)
//                    return false;
//                nanos = termination.awaitNanos(nanos);
//            }
//            return true;
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    public void setThreadFactory(ThreadFactory threadFactory) {
//        if (threadFactory == null)
//            throw new NullPointerException();
//        this.threadFactory = threadFactory;
//    }
//
    public ThreadFactory getThreadFactory() {
        return threadFactory;
    }

    //
//    public void setRejectedExecutionHandler(RejectedExecutionHandler handler) {
//        if (handler == null)
//            throw new NullPointerException();
//        this.handler = handler;
//    }
//
//    public RejectedExecutionHandler getRejectedExecutionHandler() {
//        return handler;
//    }
//
//    public boolean prestartCoreThread() {
//        return workerCountOf(ctl.get()) < CORE_POOL_SIZE && addWorker(null);
//    }
//
//    void ensurePrestart() {
//        int wc = workerCountOf(ctl.get());
//        if (wc < CORE_POOL_SIZE)
//            addWorker(null);
//        else if (wc == 0)
//            addWorker(null);
//    }
//
//    public int prestartAllCoreThreads() {
//        int n = 0;
//        while (addWorker(null)) {
//            ++n;
//        }
//        return n;
//    }
//
//    public boolean allowsCoreThreadTimeOut() {
//        return allowCoreThreadTimeOut;
//    }
//
//    public void allowCoreThreadTimeOut(boolean value) {
//        if (value && keepAliveTime <= 0)
//            throw new IllegalArgumentException("Core threads must have nonzero keep alive times");
//        if (value != allowCoreThreadTimeOut) {
//            allowCoreThreadTimeOut = value;
//            if (value)
//                interruptIdleWorkers();
//        }
//    }
//
//    public void setKeepAliveTime(long time, TimeUnit unit) {
//        if (time < 0)
//            throw new IllegalArgumentException();
//        if (time == 0 && allowsCoreThreadTimeOut())
//            throw new IllegalArgumentException("Core threads must have nonzero keep alive times");
//        long keepAliveTime = unit.toNanos(time);
//        long delta = keepAliveTime - this.keepAliveTime;
//        this.keepAliveTime = keepAliveTime;
//        if (delta < 0)
//            interruptIdleWorkers();
//    }
//
//    public long getKeepAliveTime(TimeUnit unit) {
//        return unit.convert(keepAliveTime, TimeUnit.NANOSECONDS);
//    }
//
//    public BlockingQueue<Runnable> getQueue() {
//        return workQueue;
//    }
//
//    public boolean remove(Runnable task) {
//        boolean removed = workQueue.remove(task);
//        tryTerminate(); // In case SHUTDOWN and now empty
//        return removed;
//    }
//
//    public void purge() {
//        final BlockingQueue<Runnable> q = workQueue;
//        try {
//            Iterator<Runnable> it = q.iterator();
//            while (it.hasNext()) {
//                Runnable r = it.next();
//                if (r instanceof Future<?> && ((Future<?>) r).isCancelled())
//                    it.remove();
//            }
//        } catch (ConcurrentModificationException fallThrough) {
//            for (Object r : q.toArray())
//                if (r instanceof Future<?> && ((Future<?>) r).isCancelled())
//                    q.remove(r);
//        }
//        tryTerminate(); // In case SHUTDOWN and now empty
//    }
//
//    public int getPoolSize() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            return (runStateAtLeast(ctl.get(), TIDYING) || worker.get() == null) ? 0 : 1;
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    public int getActiveCount() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            int n = 0;
//            Worker w;
//            if ((w = worker.get()) != null) {
//                if (w.isLocked())
//                    ++n;
//            }
//            return n;
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    public long getTaskCount() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            long n = completedTaskCount;
//            Worker w;
//            if ((w = worker.get()) != null) {
//                n += w.completedTasks;
//                if (w.isLocked())
//                    ++n;
//            }
//            return n + workQueue.size();
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    public long getCompletedTaskCount() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            long n = completedTaskCount;
//            Worker w;
//            if ((w = worker.get()) != null) {
//                n += w.completedTasks;
//            }
//            return n;
//        } finally {
//            mainLock.unlock();
//        }
//    }
//
//    public String toString() {
//        long ncompleted;
//        int nactive;
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            ncompleted = completedTaskCount;
//            nactive = 0;
//            Worker w;
//            if ((w = worker.get()) != null) {
//                ncompleted += w.completedTasks;
//                if (w.isLocked()) {
//                    ++nactive;
//                }
//            }
//        } finally {
//            mainLock.unlock();
//        }
//        int c = ctl.get();
//        String runState =
//                isRunning(c) ? "Running" :
//                        runStateAtLeast(c, TERMINATED) ? "Terminated" :
//                                "Shutting down";
//        return super.toString() +
//                "[" + runState +
//                ", pool size = 1, active threads = " + nactive +
//                ", queued tasks = " + workQueue.size() +
//                ", completed tasks = " + ncompleted +
//                "]";
//    }
//
//    protected void beforeExecute(Thread t, Runnable r) {
//    }
//
//    protected void afterExecute(Runnable r, Throwable t) {
//    }
//
//    protected void terminated() {
//    }
//
    public interface RejectedExecutionHandler {
        void rejectedExecution(Runnable r, ThreadPoolExecutor executor);
    }

    //    public static class CallerRunsPolicy implements RejectedExecutionHandler {
//
//        public CallerRunsPolicy() {
//        }
//
//        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
//            if (!e.isShutdown()) {
//                r.run();
//            }
//        }
//    }
//
    public static class AbortPolicy implements RejectedExecutionHandler {

        public AbortPolicy() {
        }

        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
            throw new RejectedExecutionException("Task " + r.toString() + " rejected from " + e.toString());
        }
    }
//
//    public static class DiscardPolicy implements RejectedExecutionHandler {
//
//        public DiscardPolicy() {
//        }
//
//        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
//        }
//    }
//
//    public static class DiscardOldestPolicy implements RejectedExecutionHandler {
//
//        public DiscardOldestPolicy() {
//        }
//
//        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
//            if (!e.isShutdown()) {
//                e.getQueue().poll();
//                e.execute(r);
//            }
//        }
//    }

    // VarHandle mechanics
    private static final VarHandle STATE;
    private static final VarHandle WHEAD;
    private static final VarHandle WTAIL;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            STATE = l.findVarHandle(Worker.class, "state", long.class);
            WHEAD = l.findVarHandle(Worker.class, "whead", long.class);
            WTAIL = l.findVarHandle(Worker.class, "wtail", long.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }

        // Reduce the risk of rare disastrous classloading in first call to
        // LockSupport.park: https://bugs.openjdk.java.net/browse/JDK-8074773
        Class<?> ensureLoaded = LockSupport.class;
    }
}
