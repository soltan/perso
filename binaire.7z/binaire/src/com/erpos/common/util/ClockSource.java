package com.erpos.common.util;

import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.*;

public interface ClockSource {

    TimeUnit[] TIMEUNITS_DESCENDING = {DAYS, HOURS, MINUTES, SECONDS, MILLISECONDS, MICROSECONDS, NANOSECONDS};
    String[] TIMEUNIT_DISPLAY_VALUES = {"ns", "µs", "ms", "s", "m", "h", "d"};

    static long currentTime() {
        return System.nanoTime();
    }

    static long toMillis(final long time) {
        return NANOSECONDS.toMillis(time);
    }

    static long toNanos(final long time) {
        return time;
    }

    static long elapsedMillis(final long startTime) {
        return NANOSECONDS.toMillis(System.nanoTime() - startTime);
    }

    static long elapsedMillis(final long startTime, final long endTime) {
        return NANOSECONDS.toMillis(endTime - startTime);
    }

    static long elapsedNanos(final long startTime) {
        return System.nanoTime() - startTime;
    }

    static long elapsedNanos(final long startTime, final long endTime) {
        return endTime - startTime;
    }

    static long plusMillis(final long time, final long millis) {
        return time + MILLISECONDS.toNanos(millis);
    }

    static TimeUnit getSourceTimeUnit() {
        return NANOSECONDS;
    }

    static String elapsedDisplayString(long startTime, long endTime) {
        long elapsedNanos = elapsedNanos(startTime, endTime);
        StringBuilder sb = new StringBuilder(elapsedNanos < 0 ? "-" : "");
        elapsedNanos = Math.abs(elapsedNanos);
        for (TimeUnit unit : TIMEUNITS_DESCENDING) {
            long converted = unit.convert(elapsedNanos, NANOSECONDS);
            if (converted > 0) {
                sb.append(converted).append(TIMEUNIT_DISPLAY_VALUES[unit.ordinal()]);
                elapsedNanos -= NANOSECONDS.convert(converted, unit);
            }
        }
        return sb.toString();
    }
}
