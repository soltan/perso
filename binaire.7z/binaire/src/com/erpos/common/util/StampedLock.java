package com.erpos.common.util;

import java.io.Serializable;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

public class StampedLock implements Serializable {

    private static final long serialVersionUID = -6001602636862214147L;
    private static final int NCPU = Runtime.getRuntime().availableProcessors();
    private static final int SPINS = (NCPU > 1) ? 1 << 6 : 1;
    private static final int HEAD_SPINS = (NCPU > 1) ? 1 << 10 : 1;
    private static final int MAX_HEAD_SPINS = (NCPU > 1) ? 1 << 16 : 1;
    private static final int OVERFLOW_YIELD_RATE = 7; // must be power 2 - 1
    private static final int LG_READERS = 7;
    //    // Values for lock state and stamp operations
    private static final int SHIFT = 16;
    private static final int MASK = (1 << SHIFT) - 1;

    private static final int H_SHIFT = SHIFT; //16
    private static final int T_SHIFT = H_SHIFT + SHIFT; //32
    private static final int W_SHIFT = T_SHIFT + SHIFT; //48

    private static final long R_UNIT = 1L;
    private static final long H_UNIT = 1L << H_SHIFT;
    private static final long T_UNIT = 1L << T_SHIFT;
    private static final long W_UNIT = 1L << W_SHIFT;

    private static final long WBIT = H_UNIT - 1;
    private static final long RFULL = (1L << LG_READERS) - 1L;
    private static final long ORIGIN = 0L;
    private static final long MAX_THREADS = MASK;//WBIT - 1;
    private static final long DEFAULT_TIME_SPIN_WAITING = TimeUnit.MICROSECONDS.toNanos(500);
    //
//    private static final int MAX_TIMED_SPINS = (NCPU < 2) ? 0 : 32;
//    private static final int MAX_UNTIMED_SPINS = MAX_TIMED_SPINS * 16;
//    private static final long SPIN_FOR_TIMEOUT_THRESHOLD = 1000L;
//
//
    private transient Thread exclusiveOwnerThread;
    private transient volatile long state;

    public StampedLock() {
        state = ORIGIN;
    }

    private boolean casState(long expectedValue, long newValue) {
        return STATE.compareAndSet(this, expectedValue, newValue);
    }

    private static long head(long s) {
        return (s >>> H_SHIFT) & MASK;
    }

    private static long tail(long s) {
        return (s >>> T_SHIFT) & MASK;
    }

    private static long writersCount(long s) {
        return (s >>> W_SHIFT) & MASK;
    }

    private static long readersCount(long s) {
        return s & MASK;
    }

    private static long waitersCount(long h, long t) {
        return ((t - h) & MASK);
    }

    private long activeThreads(long s, long readCount) {
        return (readCount == WBIT ? 1 : readCount) + waitersCount(head(s), tail(s));
    }

    private static long nextSecondarySeed() {
        int r;
        Thread t = Thread.currentThread();
        if ((r = ((int) SECONDARY.getVolatile(t))) != 0) {
            r ^= r << 13;   // xorshift
            r ^= r >>> 17;
            r ^= r << 5;
        } else if ((r = ThreadLocalRandom.current().nextInt()) == 0) {
            r = 1; // avoid zero
        }
        SECONDARY.setVolatile(t, r);
        return r;
    }

    private long nextStateAdvanceHead(long s) {
        return (head(s) == MASK ? (s - (H_UNIT * MASK)) : (s + H_UNIT));
    }

    private long tryAdvanceHead(long s) {
        long t, next = nextStateAdvanceHead(s);
        if (casState(s, next)) {
            return head(next);
        } else if ((nextSecondarySeed() & OVERFLOW_YIELD_RATE) == 0) {
            Thread.yield();
        } else {
            Thread.onSpinWait();
        }
        return -1L;
    }

    private long nextStateAdvanceTail(long s) {
        return (tail(s) == MASK ? (s - (T_UNIT * MASK)) : (s + T_UNIT));
    }

    private long tryAdvanceTailAndGet(long s) {
        long t, next = nextStateAdvanceTail(s);
        if (head(s) == (next = tail(next))) {
            throw new Error("Maximum lock count exceeded");
        }
        if (head(s) == (t = tail(next))) {
            throw new Error("Maximum lock count exceeded");
        }
        if (casState(s, next)) {
            return t;
        } else if ((nextSecondarySeed() & OVERFLOW_YIELD_RATE) == 0) {
            Thread.yield();
        } else {
            Thread.onSpinWait();
        }
        return -1L;
    }

    private boolean tryIncReader(long s, long activeThreads, boolean canWainting, boolean checkMaxThreads) {
        if (activeThreads >= MAX_THREADS) {
            if (checkMaxThreads) {
                throw new Error("Maximum lock count exceeded");
            }
        } else if (casState(s, s + R_UNIT)) {
            return true;
        } else if (activeThreads > RFULL && canWainting) {
            if ((nextSecondarySeed() & OVERFLOW_YIELD_RATE) == 0) {
                Thread.yield();
            } else {
                Thread.onSpinWait();
            }
        }
        return false;
    }

    ////
////    //    private boolean tryDecReader(long s, long n, boolean canWainting) {
//////        if (n <= 0L) {
//////            throw new Error("Minimum lock count exceeded");
//////        }
//////        if (casState(s, s - R_UNIT)) {
//////            return true;
//////        }
//////        if (n > RFULL && canWainting) {
//////            if ((nextSecondarySeed() & OVERFLOW_YIELD_RATE) == 0) {
//////                Thread.yield();
//////            } else {
//////                Thread.onSpinWait();
//////            }
//////        }
//////        return false;
//////    }
//////

    private boolean acquireReadLock(final Thread current) {
        long s, r;
        return (((r = readersCount(s = state)) < WBIT && writersCount(s) == 0L) || (r == WBIT && (current == exclusiveOwnerThread)))
                && (r = activeThreads(s, r)) < MAX_THREADS && tryIncReader(s, r, true, false);
    }

    public boolean tryReadLock() {
        final Thread current = Thread.currentThread();
        long s, r;
        while ((((r = readersCount(s = state)) < WBIT && writersCount(s) == 0L) || (r == WBIT && (current == exclusiveOwnerThread)))
                && (r = activeThreads(s, r)) < MAX_THREADS) {
            if (tryIncReader(s, r, true, false)) {
                return true;
            }
        }
        return false;
    }

    public boolean tryReadLock(long time, TimeUnit unit) throws InterruptedException {
        if (!Thread.interrupted()) {
            final Thread current = Thread.currentThread();
            if (acquireReadLock(current)) {
                return true;
            }
            long deadline, nanos;
            if ((nanos = unit.toNanos(time)) <= 0L) {
                return false;
            }
            if ((deadline = System.nanoTime() + nanos) == 0L) {
                deadline = 1L;
            }
            return acquireRead(current, true, deadline);
        }
        throw new InterruptedException();
    }

    public boolean readLock() {
        try {
            final Thread current = Thread.currentThread();
            return acquireReadLock(current) ? true : acquireRead(current, false, 0L);
        } catch (InterruptedException e) {
            return false;
        }
    }

    public boolean readLockInterruptibly() throws InterruptedException {
        if (!Thread.interrupted()) {
            final Thread current = Thread.currentThread();
            return (acquireReadLock(current) ? true : acquireRead(current, true, 0L));
        }
        throw new InterruptedException();
    }

    private boolean acquireRead(Thread currentThread, boolean interruptible, long deadline) throws InterruptedException {
        final Thread current = Thread.currentThread();
        long s, r, ns, h, t;
        while ((((r = readersCount(s = state)) < WBIT && writersCount(s) == 0L) || (r == WBIT && (current == exclusiveOwnerThread)))) {
            if (tryIncReader(s, activeThreads(s, r), true, false)) {
                return true;
            } else if (deadline != 0L && (deadline - System.nanoTime()) <= 0L) {
                return cancelWaiter(false);
            }
        }
        for (; ; ) {
            if (deadline != 0L && (deadline - System.nanoTime()) <= 0L) {
                return cancelWaiter(false);
            }
            if((t = tryAdvanceTailAndGet(s = state)) != -1L) {
                break;
            }
        }
        boolean wasInterrupted = false;
        for (int spins = -1; ; ) {
            if ((h = head(state)) == t) {
                if (spins < 0) {
                    spins = HEAD_SPINS;
                } else if (spins < MAX_HEAD_SPINS) {
                    spins <<= 1;
                }
                for (int i = spins; ; ) {
                    if (((r = readersCount(s = state)) < WBIT || current == exclusiveOwnerThread)
                            && tryIncReader(s, activeThreads(s, r), true, true)) {
                        if (tryAdvanceHead(s) != -1L) {
                            if (wasInterrupted) {
                                Thread.currentThread().interrupt();
                            }
                            return true;
                        }
                    } else if (r >= WBIT && --i <= 0) {
                        break;
                    } else {
                        Thread.onSpinWait();
                    }
                }
            }
            if (head(s = state) == h) {
                long time = DEFAULT_TIME_SPIN_WAITING;
                if (deadline != 0L && (time = deadline - System.nanoTime()) <= 0L) {
                    return cancelWaiter(false);
                }
                if ((t != h || readersCount(s = state) == WBIT) && head(s) == h) {
                    LockSupport.parkNanos(this, time > DEFAULT_TIME_SPIN_WAITING ? DEFAULT_TIME_SPIN_WAITING : time);
                }
                if (Thread.interrupted()) {
                    if (interruptible) {
                        return cancelWaiter(true);
                    }
                    wasInterrupted = true;
                }
            }
        }
    }

    //
//    //
////    public void unlockRead() {
////        long s, m;
////        while ((m = ((s = state) & MASK)) > 0L && m < WBIT) {
////            if (casState(s, s - R_UNIT)) {
////                if (m == 1) {
////                    int h, t;
////                    while ((h = head(s = state)) != (t = tail(s))) {
////                        if (tryAdvanceHead(s, readersCount(s), waitersCount(h, t), true)) {
////                            return;
////                        }
////                    }
////                    break;
////                }
////                return;
////            } else if (m > RFULL) {
////                if ((nextSecondarySeed() & OVERFLOW_YIELD_RATE) == 0) {
////                    Thread.yield();
////                } else {
////                    Thread.onSpinWait();
////                }
////            }
////        }
////        throw new IllegalMonitorStateException();
////    }
////
////    private boolean tryWriteLock(long s) {
////        if (casState(s, s | WBIT)) {//TODO - test
////            VarHandle.storeStoreFence();
////            return true;
////        }
////        return false;
////    }
////
////    public boolean tryWriteLock() {
////        long s;
////        while (((s = state) & MASK) == 0L && head(s) == tail(s)) {
////            if (tryWriteLock(s)) {
////                return true;
////            }
////        }
////        return false;
////    }
////
////    public boolean tryWriteLock(long time, TimeUnit unit) throws InterruptedException {
////        if (!Thread.interrupted()) {
////            long s, m, deadline, nanos;
////            if (((s = state) & MASK) == 0L && head(s) == tail(s)) {
////                if (tryWriteLock(s)) {
////                    return true;
////                }
////            }
////            if ((nanos = unit.toNanos(time)) <= 0L) {
////                return false;
////            }
////            if ((deadline = System.nanoTime() + nanos) == 0L) {
////                deadline = 1L;
////            }
////            return acquireWrite(true, deadline);
////        }
////        throw new InterruptedException();
////    }
////
////    public boolean writeLock() {
////        try {
////            return tryWriteLock() ? true : acquireWrite(false, 0L);
////        } catch (InterruptedException e) {
////            return false;
////        }
////    }
////
////    public boolean writeLockInterruptibly() throws InterruptedException {
////        if (!Thread.interrupted() && acquireWrite(true, 0L)) {
////            return true;
////        }
////        throw new InterruptedException();
////    }
////
////    //    private static long unlockWriteState(long s) {
//////        return ((s += WBIT) == 0L) ? ORIGIN : s;
//////    }
//////
////    public void unlockWrite() {
//////        long s;
//////        if (((s = state) & WBIT) == 0L) {
//////            throw new IllegalMonitorStateException();
//////        }
//////        int h, p;
//////        STATE.setVolatile(this, unlockWriteState(s));
//////        if ((h = head(s)) != (p = tail(s))) {
//////            //release(h);
//////        }
//////        return;
////    }
////
////    //
//////    public void unlock() {
//////        long s;
//////        if (((s = state) & WBIT) != 0L) {
//////            unlockWrite();
//////        } else {
//////            unlockRead();
//////        }
//////    }
//////
//////
//////    public boolean tryConvertToWriteLock() {
//////        long a = (s = state) & MASK, m, s, next;
//////        while (true) {//(s = state) == stamp) {//((s = state) & SBITS) == (stamp & SBITS)) {
//////            if ((m = ((s = state) & MASK)) == 0L) {
//////                if (a != 0L) {
//////                    break;
//////                }
//////                if (tryWriteLock(s)) {
//////                    return true;
//////                }
//////            } else if (m == WBIT) {
//////                if (a != m) {
//////                    break;
//////                }
//////                return true;
//////            } else if (m == R_UNIT && a != 0L) {
//////                if (casState(s, next = s - R_UNIT + WBIT)) {
//////                    VarHandle.storeStoreFence();
//////                    return true;
//////                }
//////            } else {
//////                break;
//////            }
//////        }
//////        return false;
//////    }
//////
//////    public boolean tryConvertToReadLock() {
//////        long stamp = state, a, s, m; int h;
//////        while (true) {//(s = state) == stamp) {//while (((s = state) & SBITS) == (stamp & SBITS)) {
//////            if ((a = ((s = state) & MASK)) >= WBIT) {
//////                // write stamp
//////                if (s != stamp)
//////                    break;
//////                STATE.setVolatile(this, unlockWriteState(s) + R_UNIT);
//////                //if ((h = head(s = state)) != null && h.status != 0)
//////                //    release(h);
//////                return true;
//////            }
//////            else if (a == 0L) {
//////                // optimistic read stamp
//////                if (( m = (s & MASK)) < WBIT && tryIncReader(s, m , true))
//////                    return true;
//////            }
//////            else {
//////                // already a read stamp
//////                if ((s & MASK) == 0L)
//////                    break;
//////                return true;
//////            }
//////        }
//////        return false;
//////    }
////////
////////    // status monitoring methods
////////
////////
////////    private int getReadLockCount(long s) {
////////        long readers;
////////        if ((readers = s & RBITS) >= RFULL)
////////            readers = RFULL + readerOverflow;
////////        return (int) readers;
////////    }
////////
////////
////////    public boolean isWriteLocked() {
////////        return (state & WBIT) != 0L;
////////    }
////////
////////
////////    public boolean isReadLocked() {
////////        return (state & RBITS) != 0L;
////////    }
////////
////////
////////    public static boolean isWriteLockStamp(long stamp) {
////////        return (stamp & ABITS) == WBIT;
////////    }
////////
////////
////////    public static boolean isReadLockStamp(long stamp) {
////////        return (stamp & RBITS) != 0L;
////////    }
////////
////////
////////    public static boolean isLockStamp(long stamp) {
////////        return (stamp & ABITS) != 0L;
////////    }
////////
////////
////////    public static boolean isOptimisticReadStamp(long stamp) {
////////        return (stamp & ABITS) == 0L && stamp != 0L;
////////    }
////////
////////
////////    public int getReadLockCount() {
////////        return getReadLockCount(state);
////////    }
////////
////////
////////    public String toString() {
////////        long s = state;
////////        return super.toString() +
////////                ((s & ABITS) == 0L ? "[Unlocked]" :
////////                        (s & WBIT) != 0L ? "[Write-locked]" :
////////                                "[Read-locks:" + getReadLockCount(s) + "]");
////////    }
////////
////////    // Needed because view-class lock methods throw away stamps.
////////
////////    final void unstampedUnlockWrite() {
////////        long s;
////////        if (((s = state) & WBIT) == 0L)
////////            throw new IllegalMonitorStateException();
////////        unlockWriteInternal(s);
////////    }
////////
////////    final void unstampedUnlockRead() {
////////        long s, m; WNode h;
////////        while ((m = (s = state) & RBITS) > 0L) {
////////            if (m < RFULL) {
////////                if (casState(s, s - RUNIT)) {
////////                    if (m == RUNIT && (h = whead) != null && h.status != 0)
////////                        release(h);
////////                    return;
////////                }
////////            }
////////            else if (tryDecReaderOverflow(s) != 0L)
////////                return;
////////        }
////////        throw new IllegalMonitorStateException();
////////    }
////////
////////    private static long nextSecondarySeed(){
////////        return 0;
////////    }
////////
//////
////    private boolean acquireWrite(boolean interruptible, long deadline) throws InterruptedException {
////        int h, p;
////        long s, m;
////        for (int spins = -1; ; ) { // spin while enqueuing
////            if ((m = (s = state) & MASK) == 0L) {
////                if (tryWriteLock(s)) {
////                    return true;
////                }
////            } else if (spins < 0) {
////                spins = (m == WBIT && tail(s = state) == head(s)) ? SPINS : 0;
////            } else if (spins > 0) {
////                --spins;
////                Thread.onSpinWait();
////            } else if (tryAdvanceTail(s)) {
////                break;
////            }
////        }
////        boolean wasInterrupted = false;
////        for (int spins = -1; ; ) {
////            if ((h = head(s = state)) == p) {
////                if (spins < 0) {
////                    spins = HEAD_SPINS;
////                } else if (spins < MAX_HEAD_SPINS) {
////                    spins <<= 1;
////                }
////                for (int k = spins; k > 0; --k) { // spin at head
////                    if ((m = (s = state) & MASK) <= 0L) {
////                        if (tryWriteLock(s)) {
////                            ////whead = node;
////                            STATE.setVolatile(this, s + H_UNIT);
////                            if (wasInterrupted) {
////                                Thread.currentThread().interrupt();
////                            }
////                            return true;
////                        }
////                    } else {
////                        Thread.onSpinWait();
////                    }
////                }
////            }
////            if (head(state) == h) {
////                long time = DEFAULT_TIME_SPIN_WAITING;
////                if (deadline != 0L && (time = deadline - System.nanoTime()) <= 0L) {
////                    return cancelWaiter(false);
////                }
////                if ((p != h || (state & MASK) != 0L) && head(s = state) == h /*&& node.prev == p*/) {
////                    LockSupport.parkNanos(this, time);
////                }
////                if (Thread.interrupted()) {
////                    if (interruptible) {
////                        return cancelWaiter(true);
////                    }
////                    wasInterrupted = true;
////                }
////            }
////        }
////    }
////
    private boolean cancelWaiter(boolean interrupted) throws InterruptedException {
        if (interrupted || Thread.interrupted()) {
            throw new InterruptedException();
        }
        return false;
    }

    private static final VarHandle STATE;
    private static final VarHandle EXCLUSIVE_OWNER_THREAD;
    private static final VarHandle SECONDARY;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            STATE = l.findVarHandle(StampedLock.class, "state", long.class);
            EXCLUSIVE_OWNER_THREAD = l.findVarHandle(StampedLock.class, "exclusiveOwnerThread", Thread.class);
            SECONDARY = MethodHandles.privateLookupIn(Thread.class, l).findVarHandle(Thread.class, "threadLocalRandomSecondarySeed", int.class);
            // Reduce the risk of rare disastrous classloading in first call to
            // LockSupport.park: https://bugs.openjdk.java.net/browse/JDK-8074773
            Class<?> ensureLoaded = LockSupport.class;
        } catch (ReflectiveOperationException e) {
            throw new Error(e);
        }
    }
}
