package com.erpos.common.util;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;

public final class FastList<T> implements Iterable<T>, RandomAccess, Serializable {
    private static final long serialVersionUID = -4598088075242913858L;
    private final Class<?> clazz;
    private T[] elementData;
    private int size;

    public FastList(Class<?> clazz) {
        this.elementData = (T[]) Array.newInstance(clazz, 32);
        this.clazz = clazz;
    }

    public FastList(Class<?> clazz, int capacity) {
        this.elementData = (T[]) Array.newInstance(clazz, capacity);
        this.clazz = clazz;
    }

    public boolean add(T element) {
        if (size < elementData.length) {
            elementData[size++] = element;
        } else {
            // overflow-conscious code
            final int oldCapacity = elementData.length;
            final int newCapacity = oldCapacity << 1;
            @SuppressWarnings("unchecked") final T[] newElementData = (T[]) Array.newInstance(clazz, newCapacity);
            System.arraycopy(elementData, 0, newElementData, 0, oldCapacity);
            newElementData[size++] = element;
            elementData = newElementData;
        }
        return true;
    }

    public T get(int index) {
        return elementData[index];
    }

    public T removeLast() {
        T element = elementData[--size];
        elementData[size] = null;
        return element;
    }

    public boolean remove(Object element) {
        for (int index = size - 1; index >= 0; index--) {
            if (element == elementData[index]) {
                final int numMoved = size - index - 1;
                if (numMoved > 0) {
                    System.arraycopy(elementData, index + 1, elementData, index, numMoved);
                }
                elementData[--size] = null;
                return true;
            }
        }

        return false;
    }

    public void clear() {
        for (int i = 0; i < size; i++) {
            elementData[i] = null;
        }
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public T set(int index, T element) {
        T old = elementData[index];
        elementData[index] = element;
        return old;
    }

    public T remove(int index) {
        if (size == 0) {
            return null;
        }
        final T old = elementData[index];
        final int numMoved = size - index - 1;
        if (numMoved > 0) {
            System.arraycopy(elementData, index + 1, elementData, index, numMoved);
        }
        elementData[--size] = null;
        return old;
    }

    public boolean contains(Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private int index;

            @Override
            public boolean hasNext() {
                return index < size;
            }

            @Override
            public T next() {
                if (index < size) {
                    return elementData[index++];
                }
                throw new NoSuchElementException("No more elements in FastList");
            }
        };
    }
}
