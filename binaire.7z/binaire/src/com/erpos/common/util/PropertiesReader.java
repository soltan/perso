package com.erpos.common.util;

import java.util.Optional;
import java.util.Properties;

public class PropertiesReader {

    private final Properties properties;

    public PropertiesReader(Properties properties) {
        this.properties = properties;
    }

    public String getString(String prop) {
        return properties.getProperty(prop);
    }

    public String getString(String prop, String defaultValue) {
        return Optional.ofNullable(getString(prop)).orElse(defaultValue);
    }

    public Integer getInteger(String prop) {
        return getInteger(prop, null);
    }

    public Integer getInteger(String prop, Integer defaultValue) {
        try {
            return Optional.ofNullable(getString(prop)).map(Integer::valueOf).orElse(defaultValue);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public boolean getBoolean(String prop) {
        return Optional.ofNullable(getString(prop)).map(Boolean::valueOf).orElse(false);
    }

    public Long getLong(String prop) {
        return getLong(prop, null);
    }

    public Long getLong(String prop, Long defaultValue) {
        try {
            return Optional.ofNullable(getString(prop)).map(Long::valueOf).orElse(defaultValue);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
