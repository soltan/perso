package com.erpos.common.util;

import jdk.internal.vm.annotation.ReservedStackAccess;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

public class ReentrantReadWriteLockOrigCorrect implements java.io.Serializable {
    private static final long serialVersionUID = -6992448646407690164L;

    static final int SHARED_SHIFT = 16;
    static final int SHARED_UNIT = (1 << SHARED_SHIFT);
    static final int MAX_COUNT = (1 << SHARED_SHIFT) - 1;
    static final int EXCLUSIVE_MASK = (1 << SHARED_SHIFT) - 1;

    static final long SPIN_FOR_TIMEOUT_THRESHOLD = 1000L;

    static int sharedCount(int c) {
        return c >>> SHARED_SHIFT;
    }

    static int exclusiveCount(int c) {
        return c & EXCLUSIVE_MASK;
    }

    static long getThreadId(Thread thread) {
        return 0L;//LockSupport.getThreadId(Thread.currentThread())
    }

    private transient Thread exclusiveOwnerThread;
    private transient ThreadLocalHoldCounter readHolds;
    private transient HoldCounter cachedHoldCounter;

    private transient Thread firstReader;
    private transient int firstReaderHoldCount;

    private volatile int state;
    private transient volatile Node head;
    private transient volatile Node tail;
    private transient volatile Node waitWriters;


    public ReentrantReadWriteLockOrigCorrect() {
        readHolds = new ThreadLocalHoldCounter();
        setState(getState()); // ensures visibility of readHolds
    }

    protected final int getState() {
        return state;
    }

    protected final void setState(int newState) {
        state = newState;
    }

    protected final void setExclusiveOwnerThread(Thread thread) {
        exclusiveOwnerThread = thread;
    }

    protected final Thread getExclusiveOwnerThread() {
        return exclusiveOwnerThread;
    }


    static final class HoldCounter {
        int count;          // initially 0
        // Use id, not reference, to avoid garbage retention
        final long tid = getThreadId(Thread.currentThread());
    }


    static final class ThreadLocalHoldCounter
            extends ThreadLocal<HoldCounter> {
        public HoldCounter initialValue() {
            return new HoldCounter();
        }
    }

    final boolean readerShouldBlock() {
        return hasQueuedPredecessors();
    }


    final boolean writerShouldBlock() {
        return hasQueuedPredecessors();
    }

    public final boolean hasQueuedPredecessors() {
        Node h, s;
        if ((h = head) != null) {
            if ((s = h.next) == null || s.waitStatus > 0) {
                s = null; // traverse in case of concurrent cancellation
                for (Node p = tail; p != h && p != null; p = p.prev) {
                    if (p.waitStatus <= 0)
                        s = p;
                }
            }
            if (s != null && s.thread != Thread.currentThread()) {
                return true;
            }
        }
        return false;
    }

    @ReservedStackAccess
    protected final boolean tryAcquire(int acquires) {
        Thread current = Thread.currentThread();
        int c = getState();
        int w = exclusiveCount(c);
        if (c != 0) {
            // (Note: if c != 0 and w == 0 then shared count != 0)
            if (w == 0 || current != getExclusiveOwnerThread())
                return false;
            if (w + exclusiveCount(acquires) > MAX_COUNT)
                throw new Error("Maximum lock count exceeded");
            // Reentrant acquire
            setState(c + acquires);
            return true;
        }
        if (writerShouldBlock() ||
                !compareAndSetState(c, c + acquires))
            return false;
        setExclusiveOwnerThread(current);
        return true;
    }

    private static IllegalMonitorStateException unmatchedUnlockException() {
        return new IllegalMonitorStateException(
                "attempt to unlock read lock, not locked by current thread");
    }

    @ReservedStackAccess
    protected final boolean tryAcquireShared() {
        Thread current = Thread.currentThread();
        int s;
        if (exclusiveCount(s = state) != 0 && getExclusiveOwnerThread() != current) {
            return false;
        }
        int r = sharedCount(s);
        if (!readerShouldBlock() && r < MAX_COUNT && compareAndSetState(s, s + SHARED_UNIT)) {
            if (r == 0) {
                firstReader = current;
                firstReaderHoldCount = 1;
            } else if (firstReader == current) {
                firstReaderHoldCount++;
            } else {
                HoldCounter rh = cachedHoldCounter;
                if (rh == null || rh.tid != getThreadId(current))
                    cachedHoldCounter = rh = readHolds.get();
                else if (rh.count == 0)
                    readHolds.set(rh);
                rh.count++;
            }
            return true;
        }
        return fullTryAcquireShared(current);
    }


    final boolean fullTryAcquireShared(Thread current) {
        HoldCounter rh = null;
        for (int s; ; ) {
            if (exclusiveCount(s = state) != 0) {
                if (getExclusiveOwnerThread() != current) {
                    return false;
                }
                // else we hold the exclusive lock; blocking here
                // would cause deadlock.
            } else if (readerShouldBlock()) {
                // Make sure we're not acquiring read lock reentrantly
                if (firstReader == current) {
                    // assert firstReaderHoldCount > 0;
                } else {
                    if (rh == null) {
                        rh = cachedHoldCounter;
                        if (rh == null || rh.tid != getThreadId(current)) {
                            rh = readHolds.get();
                            if (rh.count == 0)
                                readHolds.remove();
                        }
                    }
                    if (rh.count == 0) {
                        return false;
                    }
                }
            }
            if (sharedCount(s) == MAX_COUNT)
                throw new Error("Maximum lock count exceeded");
            if (compareAndSetState(s, s + SHARED_UNIT)) {
                if (sharedCount(s) == 0) {
                    firstReader = current;
                    firstReaderHoldCount = 1;
                } else if (firstReader == current) {
                    firstReaderHoldCount++;
                } else {
                    if (rh == null)
                        rh = cachedHoldCounter;
                    if (rh == null || rh.tid != getThreadId(current))
                        rh = readHolds.get();
                    else if (rh.count == 0)
                        readHolds.set(rh);
                    rh.count++;
                    cachedHoldCounter = rh; // cache for release
                }
                return true;
            }
        }
    }

    protected final boolean isHeldExclusively() {
        // While we must in general read state before owner,
        // we don't need to do so to check if current thread is owner
        return getExclusiveOwnerThread() == Thread.currentThread();
    }

//
//    final int getCount() {
//        return getState();
//    }

    public void readLock() {
        if (!tryAcquireShared()) {
            final Node node = addWaiter(Node.SHARED);
            boolean interrupted = false;
            try {
                for (; ; ) {
                    final Node p = node.predecessor();
                    if (p == head) {
                        if (tryAcquireShared()) {
                            setHeadAndPropagate(node);
                            p.next = null; // help GC
                            return;
                        }
                    }
                    if (shouldParkAfterFailedAcquire(p, node))
                        interrupted |= parkAndCheckInterrupt();
                }
            } catch (Throwable t) {
                cancelAcquire(node);
                throw t;
            } finally {
                if (interrupted)
                    selfInterrupt();
            }
        }
    }

    public void readLockInterruptibly() throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        if (!tryAcquireShared()) {
            final Node node = addWaiter(Node.SHARED);
            try {
                for (; ; ) {
                    final Node p = node.predecessor();
                    if (p == head) {
                        if (tryAcquireShared()) {
                            setHeadAndPropagate(node);
                            p.next = null; // help GC
                            return;
                        }
                    }
                    if (shouldParkAfterFailedAcquire(p, node) &&
                            parkAndCheckInterrupt()) {
                        throw new InterruptedException();
                    }
                }
            } catch (Throwable t) {
                cancelAcquire(node);
                throw t;
            }
        }
    }

    @ReservedStackAccess
    public final boolean tryReadLock() {
        Thread current = Thread.currentThread();
        for (; ; ) {
            int c = getState();
            if (exclusiveCount(c) != 0 &&
                    getExclusiveOwnerThread() != current)
                return false;
            int r = sharedCount(c);
            if (r == MAX_COUNT)
                throw new Error("Maximum lock count exceeded");
            if (compareAndSetState(c, c + SHARED_UNIT)) {
                if (r == 0) {
                    firstReader = current;
                    firstReaderHoldCount = 1;
                } else if (firstReader == current) {
                    firstReaderHoldCount++;
                } else {
                    HoldCounter rh = cachedHoldCounter;
                    if (rh == null || rh.tid != getThreadId(current))
                        cachedHoldCounter = rh = readHolds.get();
                    else if (rh.count == 0)
                        readHolds.set(rh);
                    rh.count++;
                }
                return true;
            }
        }
    }

    public boolean tryReadLock(long timeout, TimeUnit unit)
            throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        if (tryAcquireShared()) {
            return true;
        }
        long nanosTimeout = unit.toNanos(timeout);
        if (nanosTimeout <= 0L)
            return false;
        final long deadline = System.nanoTime() + nanosTimeout;
        final Node node = addWaiter(Node.SHARED);
        try {
            for (; ; ) {
                final Node p = node.predecessor();
                if (p == head) {
                    if (tryAcquireShared()) {
                        setHeadAndPropagate(node);
                        p.next = null; // help GC
                        return true;
                    }
                }
                nanosTimeout = deadline - System.nanoTime();
                if (nanosTimeout <= 0L) {
                    cancelAcquire(node);
                    return false;
                }
                if (shouldParkAfterFailedAcquire(p, node) &&
                        nanosTimeout > SPIN_FOR_TIMEOUT_THRESHOLD)
                    LockSupport.parkNanos(this, nanosTimeout);
                if (Thread.interrupted())
                    throw new InterruptedException();
            }
        } catch (Throwable t) {
            cancelAcquire(node);
            throw t;
        }
    }

    public boolean unlockRead() {
        final int arg = 1;
        Thread current = Thread.currentThread();
        if (firstReader == current) {
            // assert firstReaderHoldCount > 0;
            if (firstReaderHoldCount == 1)
                firstReader = null;
            else
                firstReaderHoldCount--;
        } else {
            HoldCounter rh = cachedHoldCounter;
            if (rh == null || rh.tid != getThreadId(current))
                rh = readHolds.get();
            int count = rh.count;
            if (count <= 1) {
                readHolds.remove();
                if (count <= 0)
                    throw unmatchedUnlockException();
            }
            --rh.count;
        }
        for (; ; ) {
            int c = getState();
            int nextc = c - SHARED_UNIT;
            if (compareAndSetState(c, nextc)) {
                if (nextc == 0) {
                    doReleaseShared();
                    return true;
                }
                return false;
            }
        }
    }

    public boolean writeLock() {
        final int arg = 1;
        if (!tryAcquire(arg)) {
            final Node node = addWaiter(Node.EXCLUSIVE);
            boolean interrupted = false;
            try {
                for (; ; ) {
                    final Node p = node.predecessor();
                    if (p == head && tryAcquire(arg)) {
                        setHead(node);
                        p.next = null; // help GC
                        if (interrupted) {
                            selfInterrupt();
                        }
                        return interrupted;
                    }
                    if (shouldParkAfterFailedAcquire(p, node)) {
                        interrupted |= parkAndCheckInterrupt();
                    }
                }
            } catch (Throwable t) {
                cancelAcquire(node);
                if (interrupted) {
                    selfInterrupt();
                }
                throw t;
            }
        }
        return false;
    }

    public void writeLockInterruptibly() throws InterruptedException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        final int arg = 1;
        if (!tryAcquire(arg)) {
            final Node node = addWaiter(Node.EXCLUSIVE);
            try {
                for (; ; ) {
                    final Node p = node.predecessor();
                    if (p == head && tryAcquire(arg)) {
                        setHead(node);
                        p.next = null; // help GC
                        return;
                    }
                    if (shouldParkAfterFailedAcquire(p, node) &&
                            parkAndCheckInterrupt())
                        throw new InterruptedException();
                }
            } catch (Throwable t) {
                cancelAcquire(node);
                throw t;
            }
        }
    }

    @ReservedStackAccess
    final boolean tryWriteLock() {
        Thread current = Thread.currentThread();
        int c = getState();
        if (c != 0) {
            int w = exclusiveCount(c);
            if (w == 0 || current != getExclusiveOwnerThread())
                return false;
            if (w == MAX_COUNT)
                throw new Error("Maximum lock count exceeded");
        }
        if (!compareAndSetState(c, c + 1))
            return false;
        setExclusiveOwnerThread(current);
        return true;
    }


    public boolean tryWriteLock(long timeout, TimeUnit unit)
            throws InterruptedException {
        final int arg = 1;
        if (tryAcquireShared()) {
            return true;
        }
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        long nanosTimeout = unit.toNanos(timeout);
        if (tryAcquire(arg)) {
            return true;
        }
        if (nanosTimeout <= 0L)
            return false;
        final long deadline = System.nanoTime() + nanosTimeout;
        final Node node = addWaiter(Node.EXCLUSIVE);
        try {
            for (; ; ) {
                final Node p = node.predecessor();
                if (p == head && tryAcquire(arg)) {
                    setHead(node);
                    p.next = null; // help GC
                    return true;
                }
                nanosTimeout = deadline - System.nanoTime();
                if (nanosTimeout <= 0L) {
                    cancelAcquire(node);
                    return false;
                }
                if (shouldParkAfterFailedAcquire(p, node) &&
                        nanosTimeout > SPIN_FOR_TIMEOUT_THRESHOLD)
                    LockSupport.parkNanos(this, nanosTimeout);
                if (Thread.interrupted())
                    throw new InterruptedException();
            }
        } catch (Throwable t) {
            cancelAcquire(node);
            throw t;
        }
    }

    public void unlockWrite() {
        final int releases = 1;
        if (!isHeldExclusively()) {
            throw new IllegalMonitorStateException();
        }
        int nextc = getState() - releases;
        boolean free = exclusiveCount(nextc) == 0;
        if (free) {
            setExclusiveOwnerThread(null);
        }
        setState(nextc);
        if (free) {
            Node h = head;
            if (h != null && h.waitStatus != 0) {
                unparkSuccessor(h);
            }
//            return true;
        }
        //       return false;
    }
//
//    // Instrumentation and status
//    //----------------------------------
//
//    public final boolean isFair() {
//        return isFair;
//    }
//
//
//    protected Thread getOwner() {
//        // Must read state before owner to ensure memory consistency
//        return ((exclusiveCount(getState()) == 0) ?
//                null :
//                getExclusiveOwnerThread());
//    }
//
//
//    public int getReadLockCount() {
//        return sharedCount(getState());
//    }
//
//
//    public boolean isWriteLocked() {
//        return exclusiveCount(getState()) != 0;
//    }
//
//
//    public boolean isWriteLockedByCurrentThread() {
//        return isHeldExclusively();
//    }
//
//
//    public int getWriteHoldCount() {
//        return isHeldExclusively() ? exclusiveCount(getState()) : 0;
//    }
//
//
//    public int getReadHoldCount() {
//        if (getReadLockCount() == 0)
//            return 0;
//        Thread current = Thread.currentThread();
//        if (firstReader == current)
//            return firstReaderHoldCount;
//        HoldCounter rh = cachedHoldCounter;
//        if (rh != null && rh.tid == getThreadId(current))
//            return rh.count;
//
//        int count = readHolds.get().count;
//        if (count == 0) readHolds.remove();
//        return count;
//    }
//
//
//    protected Collection<Thread> getQueuedWriterThreads() {
//        return getExclusiveQueuedThreads();
//    }
//
//
//    protected Collection<Thread> getQueuedReaderThreads() {
//        return getSharedQueuedThreads();
//    }
//
//
//    public final boolean hasQueuedThread(Thread thread) {
//        return isQueued(thread);
//    }
//
//    public boolean hasWaiters(Condition condition) {
//        if (condition == null)
//            throw new NullPointerException();
//        if (!(condition instanceof AbstractQueuedSynchronizer.ConditionObject))
//            throw new IllegalArgumentException("not owner");
//        return hasWaiters((AbstractQueuedSynchronizer.ConditionObject) condition);
//    }
//
//
//    public int getWaitQueueLength(Condition condition) {
//        if (condition == null)
//            throw new NullPointerException();
//        if (!(condition instanceof AbstractQueuedSynchronizer.ConditionObject))
//            throw new IllegalArgumentException("not owner");
//        return getWaitQueueLength((AbstractQueuedSynchronizer.ConditionObject) condition);
//    }
//
//    protected Collection<Thread> getWaitingThreads(Condition condition) {
//        if (condition == null)
//            throw new NullPointerException();
//        if (!(condition instanceof AbstractQueuedSynchronizer.ConditionObject))
//            throw new IllegalArgumentException("not owner");
//        return getWaitingThreads((AbstractQueuedSynchronizer.ConditionObject) condition);
//    }
//
//    public String toString() {
//        int c = getCount();
//        int w = exclusiveCount(c);
//        int r = sharedCount(c);
//        return super.toString() + "[Write locks = " + w + ", Read locks = " + r + "]";
//    }

//////////////////////////7zzzzzzzzzzzzzzz

    private Node addWaiter(Node mode) {
        Node node = new Node(mode);
        for (; ; ) {
            Node oldTail = tail;
            if (oldTail != null) {
                node.setPrevRelaxed(oldTail);
                if (compareAndSetTail(oldTail, node)) {
                    oldTail.next = node;
                    return node;
                }
            } else {
                initializeSyncQueue();
            }
        }
    }

    private void setHeadAndPropagate(Node node) {
        Node h = head; // Record old head for check below
        setHead(node);
//        if (propagate > 0 || h == null || h.waitStatus < 0 ||
//                (h = head) == null || h.waitStatus < 0) {
        Node s = node.next;
        if (s == null || s.isShared())
            doReleaseShared();
//        }
    }

    private void doReleaseShared() {
        for (; ; ) {
            Node h = head;
            if (h != null && h != tail) {
                int ws = h.waitStatus;
                if (ws == Node.SIGNAL) {
                    if (!h.compareAndSetWaitStatus(Node.SIGNAL, 0))
                        continue;            // loop to recheck cases
                    unparkSuccessor(h);
                } else if (ws == 0 &&
                        !h.compareAndSetWaitStatus(0, Node.PROPAGATE))
                    continue;                // loop on failed CAS
            }
            if (h == head)                   // loop if head changed
                break;
        }
    }

    private void unparkSuccessor(Node node) {
        int ws = node.waitStatus;
        if (ws < 0)
            node.compareAndSetWaitStatus(ws, 0);
        Node s = node.next;
        if (s == null || s.waitStatus > 0) {
            s = null;
            for (Node p = tail; p != node && p != null; p = p.prev)
                if (p.waitStatus <= 0)
                    s = p;
        }
        if (s != null)
            LockSupport.unpark(s.thread);
    }

    private void setHead(Node node) {
        head = node;
        node.thread = null;
        node.prev = null;
    }

    private final boolean compareAndSetTail(Node expect, Node update) {
        return TAIL.compareAndSet(this, expect, update);
    }

    private final void initializeSyncQueue() {
        Node h;
        if (HEAD.compareAndSet(this, null, (h = new Node())))
            tail = h;
    }

    private static boolean shouldParkAfterFailedAcquire(Node pred, Node node) {
        int ws = pred.waitStatus;
        if (ws == Node.SIGNAL)
            return true;
        if (ws > 0) {
            do {
                node.prev = pred = pred.prev;
            } while (pred.waitStatus > 0);
            pred.next = node;
        } else {
            pred.compareAndSetWaitStatus(ws, Node.SIGNAL);
        }
        return false;
    }

    private final boolean parkAndCheckInterrupt() {
        LockSupport.park(this);
        return Thread.interrupted();
    }

    private void cancelAcquire(Node node) {
        // Ignore if node doesn't exist
        if (node == null)
            return;
        node.thread = null;
        Node pred = node.prev;
        while (pred.waitStatus > 0)
            node.prev = pred = pred.prev;
        Node predNext = pred.next;
        node.waitStatus = Node.CANCELLED;
        if (node == tail && compareAndSetTail(node, pred)) {
            pred.compareAndSetNext(predNext, null);
        } else {
            int ws;
            if (pred != head &&
                    ((ws = pred.waitStatus) == Node.SIGNAL ||
                            (ws <= 0 && pred.compareAndSetWaitStatus(ws, Node.SIGNAL))) &&
                    pred.thread != null) {
                Node next = node.next;
                if (next != null && next.waitStatus <= 0)
                    pred.compareAndSetNext(predNext, next);
            } else {
                unparkSuccessor(node);
            }
            node.next = node; // help GC
        }
    }

    static void selfInterrupt() {
        Thread.currentThread().interrupt();
    }

    protected final boolean compareAndSetState(int expect, int update) {
        return STATE.compareAndSet(this, expect, update);
    }

    static final class Node {
        /**
         * Marker to indicate a node is waiting in shared mode
         */
        static final Node SHARED = new Node();
        /**
         * Marker to indicate a node is waiting in exclusive mode
         */
        static final Node EXCLUSIVE = null;
        /**
         * waitStatus value to indicate thread has cancelled.
         */
        static final int CANCELLED = 1;
        /**
         * waitStatus value to indicate successor's thread needs unparking.
         */
        static final int SIGNAL = -1;
        /**
         * waitStatus value to indicate thread is waiting on condition.
         */
        static final int CONDITION = -2;
        static final int PROPAGATE = -3;
        volatile int waitStatus;
        volatile Node prev;
        volatile Node next;
        volatile Thread thread;
        Node nextWaiter;

        final boolean isShared() {
            return nextWaiter == SHARED;
        }

        final Node predecessor() {
            Node p = prev;
            if (p == null)
                throw new NullPointerException();
            else
                return p;
        }

        Node() {
        }

        Node(Node nextWaiter) {
            this.nextWaiter = nextWaiter;
            THREAD.set(this, Thread.currentThread());
        }

        Node(int waitStatus) {
            WAITSTATUS.set(this, waitStatus);
            THREAD.set(this, Thread.currentThread());
        }

        final boolean compareAndSetWaitStatus(int expect, int update) {
            return WAITSTATUS.compareAndSet(this, expect, update);
        }

        final boolean compareAndSetNext(Node expect, Node update) {
            return NEXT.compareAndSet(this, expect, update);
        }

        final void setPrevRelaxed(Node p) {
            PREV.set(this, p);
        }

        // VarHandle mechanics
        private static final VarHandle NEXT;
        private static final VarHandle PREV;
        private static final VarHandle THREAD;
        private static final VarHandle WAITSTATUS;

        static {
            try {
                MethodHandles.Lookup l = MethodHandles.lookup();
                NEXT = l.findVarHandle(Node.class, "next", Node.class);
                PREV = l.findVarHandle(Node.class, "prev", Node.class);
                THREAD = l.findVarHandle(Node.class, "thread", Thread.class);
                WAITSTATUS = l.findVarHandle(Node.class, "waitStatus", int.class);
            } catch (ReflectiveOperationException e) {
                throw new ExceptionInInitializerError(e);
            }
        }
    }

    // VarHandle mechanics
    private static final VarHandle STATE;
    private static final VarHandle HEAD;
    private static final VarHandle TAIL;
    private static final VarHandle WAITWRITERS;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            STATE = l.findVarHandle(ReentrantReadWriteLockOrigCorrect.class, "state", int.class);
            HEAD = l.findVarHandle(ReentrantReadWriteLockOrigCorrect.class, "head", Node.class);
            TAIL = l.findVarHandle(ReentrantReadWriteLockOrigCorrect.class, "tail", Node.class);
            WAITWRITERS = l.findVarHandle(ReentrantReadWriteLockOrigCorrect.class, "waitWriters", Node.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }

        // Reduce the risk of rare disastrous classloading in first call to
        // LockSupport.park: https://bugs.openjdk.java.net/browse/JDK-8074773
        Class<?> ensureLoaded = LockSupport.class;
    }
}
