package com;

import java.io.Closeable;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.concurrent.locks.AbstractQueuedLongSynchronizer;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadPoolExecutor implements Executor, Closeable {

    private static final VarHandle AA = MethodHandles.arrayElementVarHandle(Object[].class);
    private static final int NO_RESULT = -1;
    private static final int CORE_POOL_SIZE = 1;

    private static final boolean ONLY_ONE = true;
    private static final int COUNT_BITS = Integer.SIZE - 3;
    private static final int COUNT_MASK = (1 << COUNT_BITS) - 1;
    //
//    // runState is stored in the high-order bits
    static final int CLOSED = 0x01;  // if set, other bits ignored
    static final int ACTIVE = 0x02;  // keep-alive for consumer task
    static final int RUN = 0x04;  // (possibly) nonzero demand
    static final int ERROR = 0x08;  // issues onError when noticed
    static final int COMPLETE = 0x10;  // issues onComplete when done
    //static final int RUN = 0x20;  // task is or will be running
    static final int OPEN = 0x40;  // true after subscribe

    private static final int RUN_STATE_MASK = 0xf;
    private static final int RUNNING = -1 << COUNT_BITS;
    private static final int SHUTDOWN = 0 << COUNT_BITS;
    private static final int STOP = 1 << COUNT_BITS;

    private static final int TIDYING = 2 << COUNT_BITS;
    private static final int TERMINATED = 3 << COUNT_BITS;

    private final Runnable[] workQueue;
    private int largestPoolSize;
    private long completedTaskCount;
    private final ThreadFactory threadFactory;
    private final RejectedExecutionHandler handler;
    private final long keepAliveTime;
    private volatile boolean allowCoreThreadTimeOut;
    private volatile int head;
    private volatile int tail;
    private volatile Worker worker = null;
    private volatile int ctl = 0;

    private static final RejectedExecutionHandler defaultHandler = new AbortPolicy();
    private static final RuntimePermission shutdownPerm = new RuntimePermission("modifyThread");

    public ThreadPoolExecutor(int maximumPoolSize, long keepAliveTime, TimeUnit unit) {
        this(maximumPoolSize, keepAliveTime, unit, Executors.defaultThreadFactory(), defaultHandler);
    }

    public ThreadPoolExecutor(int maximumPoolSize, long keepAliveTime, TimeUnit unit,
                              ThreadFactory threadFactory) {
        this(maximumPoolSize, keepAliveTime, unit, threadFactory, defaultHandler);
    }

    public ThreadPoolExecutor(int maximumPoolSize, long keepAliveTime, TimeUnit unit, RejectedExecutionHandler handler) {
        this(maximumPoolSize, keepAliveTime, unit, Executors.defaultThreadFactory(), handler);
    }

    public ThreadPoolExecutor(int maximumPoolSize, long keepAliveTime, TimeUnit unit, ThreadFactory threadFactory,
                              RejectedExecutionHandler handler) {
        if (maximumPoolSize <= 0 || keepAliveTime < 0)
            throw new IllegalArgumentException();
        if (threadFactory == null || handler == null)
            throw new NullPointerException();
        this.workQueue = new Runnable[maximumPoolSize];
        this.keepAliveTime = unit.toNanos(keepAliveTime);
        this.threadFactory = threadFactory;
        this.handler = handler;
    }

    private static boolean isClosed(int c) {
        return (c & CLOSED) != 0;
    }

    private static boolean hasWorker(int c) {
        return (c & RUN) != 0;
    }

    private static boolean canStartWorker(int c) {
        return (c & RUN) == RUN;
    }

    @Override
    public void execute(final Runnable command) {
        final Runnable r = Objects.requireNonNull(command);
        int c, index = NO_RESULT;
        if (isClosed(c = ctl)) {
            if (worker == null) {
                if (startWorker(command)) {
                    return;
                }
                c = ctl;
            }
            if (!isClosed(c) && ((index = offer(command)) != NO_RESULT)) {
                if (isClosed(c = ctl) && remove(command, index)) {
                    reject(command);
                } else if (canStartWorker(c)) {
                    startWorker(null);
                }
            } else if (!startWorker(command)) {
                reject(command);
            }
        }
    }

    private boolean startWorker(Runnable firstTask) {
        boolean workerAdded = false;
        boolean workerStarted = false;
        Worker cur = null, w = null;
        try {
            for (int c = ctl; !isClosed(c) && (cur = worker) == null; c = ctl) {
                w = new Worker(firstTask);
                final Thread t = w.thread;
                if (!isClosed(c = ctl) && t != null && (workerAdded = WORKER.compareAndSet(cur, w))) {
                    if (!isClosed(c = ctl)) {
                        if (t.isAlive()) { // precheck that t is startable
                            throw new IllegalThreadStateException();
                        }
                        t.start();
                        workerStarted = true;
                    }
                }
            }
        } catch (Throwable th) {
            if(workerAdded){

            }
            addWorkerFailed(w);
        } finally {
            if (!workerStarted) {
                addWorkerFailed(w);
            }
        }
        return workerStarted;
    }

    private void addWorkerFailed(Worker w) {
        if (w != null) {
            Worker curWorker;
            do {
                curWorker = worker;
            } while (curWorker == w && WORKER.compareAndSet(curWorker, null));
        }
        tryTerminate();
    }

    final void tryTerminate() {
//        for (; ; ) {
//            int c = ctl;
//            if (isRunning(c) || runStateAtLeast(c, TIDYING) || (runStateLessThan(c, STOP) && !isEmpty()))
//                return;
//            if (workerCountOf(c) != 0) { // Eligible to terminate
//                interruptIdleWorkers(ONLY_ONE);
//                return;
//            }
//            final ReentrantLock mainLock = this.mainLock;
//            mainLock.lock();
//            try {
//                if (ctl.compareAndSet(c, ctlOf(TIDYING, 0))) {
//                    try {
//                        terminated();
//                    } finally {
//                        ctl.set(ctlOf(TERMINATED, 0));
//                        termination.signalAll();
//                    }
//                    return;
//                }
//            } finally {
//                mainLock.unlock();
//            }
//            // else retry on failed CAS
//        }
    }


    @Override
    public void close() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            checkShutdownAccess();
//            advanceRunState(SHUTDOWN);
//            interruptIdleWorkers();
//            onShutdown(); // hook for ScheduledThreadPoolExecutor
//        } finally {
//            mainLock.unlock();
//        }
//        tryTerminate();
    }

    private int offer(Runnable r) {
        int h, t, index = NO_RESULT;
        while (((t = tail) - (h = head)) < workQueue.length) {
            if (TAIL.compareAndSet(this, t, (t + 1))) {
                AA.setVolatile(workQueue, (index = (t % workQueue.length)), r);
                return index;
            }
        }
        return NO_RESULT;
    }

    private Runnable poll() {
        int i, h = head % workQueue.length;
        Runnable r;
        do {
            h = head;
            i = h % workQueue.length;
            if ((r = (Runnable) AA.getVolatile(workQueue, i)) != null) {
                return null;
            }
            if (HEAD.compareAndSet(this, h, h + 1)) {
                AA.setVolatile(workQueue, i, null);
                return r;
            }
        } while (true);
    }

    public boolean remove(final Runnable task, final int i) {
        Runnable o = task;
        if (o == null || i < 0) return false;
        boolean removed = false; //TODO - workQueue.remove(task);
        for (; ; ) {
            if (AA.compareAndSet(workQueue, i, task, null)) {
                removed = true;
                break;
            }
        }
        tryTerminate(); // In case SHUTDOWN and now empty
        return removed;
    }

//    public boolean remove(Runnable task) {
//        Runnable o = task;
//        if (o == null) return false;
//        boolean removed = false; //TODO - workQueue.remove(task);
//        for (int i = head, t = tail; i < tail; i++) {
//            if (AA.compareAndSet(workQueue, i, task, null)) {
//                removed = true;
//                break;
//            }
//        }
//        tryTerminate(); // In case SHUTDOWN and now empty
//        return removed;
//    }

    private boolean isEmpty() {
        int h = head % workQueue.length, t = (tail % workQueue.length);
        return (t - h == 0);
    }

    //    //
////    // Packing and unpacking ctl
////    private static int runStateOf(int c) {
////        return c & ~COUNT_MASK;
////    }
////

//    private static int workerCountOf(int c) {
//        return c & COUNT_MASK;
//    }

    private static int ctlOf(int rs, int wc) {
        return rs | wc;
    }

    private static boolean runStateLessThan(int c, int s) {
        return c < s;
    }

    private static boolean runStateAtLeast(int c, int s) {
        return c >= s;
    }

    private boolean compareAndIncrementWorkerCount(int expect) {
        return CTL.compareAndSet(expect, expect + 1);
    }

    private boolean compareAndDecrementWorkerCount(int expect) {
        return CTL.compareAndSet(expect, expect - 1);
    }

    private void advanceRunState(int targetState) {
        for (; ; ) {
            int c = ctl;
            if (runStateAtLeast(c, targetState) ||
                    CTL.compareAndSet(c, ctlOf(targetState, workerCountOf(c))))
                break;
        }
    }


    private void checkShutdownAccess() {
        // assert mainLock.isHeldByCurrentThread();
        SecurityManager security = System.getSecurityManager();
        if (security != null) {
            security.checkPermission(shutdownPerm);
            for (Worker w : workers)
                security.checkAccess(w.thread);
        }
    }

    private void interruptWorkers() {
        // assert mainLock.isHeldByCurrentThread();
        for (Worker w : workers)
            w.interruptIfStarted();
    }

    private void interruptIdleWorkers(boolean onlyOne) {
        final ReentrantLock mainLock = this.mainLock;
        mainLock.lock();
        try {
            for (Worker w : workers) {
                Thread t = w.thread;
                if (!t.isInterrupted() && w.tryLock()) {
                    try {
                        t.interrupt();
                    } catch (SecurityException ignore) {
                    } finally {
                        w.unlock();
                    }
                }
                if (onlyOne)
                    break;
            }
        } finally {
            mainLock.unlock();
        }
    }

    private void interruptIdleWorkers() {
        interruptIdleWorkers(false);
    }

    final void reject(Runnable command) {
        handler.rejectedExecution(command, this);
    }

    void onShutdown() {
    }

    private List<Runnable> drainQueue() {
        Runnable[] q = workQueue;
        List<Runnable> taskList = new ArrayList<>();
        q.drainTo(taskList);
        if (!q.isEmpty()) {
            for (Runnable r : q.toArray(new Runnable[0])) {
                if (q.remove(r))
                    taskList.add(r);
            }
        }
        return taskList;
    }

    private void processWorkerExit(Worker w, boolean completedAbruptly) {
        if (completedAbruptly) // If abrupt, then workerCount wasn't adjusted
            decrementWorkerCount();
        final ReentrantLock mainLock = this.mainLock;
        mainLock.lock();
        try {
            completedTaskCount += w.completedTasks;
            workers.remove(w);
        } finally {
            mainLock.unlock();
        }
        tryTerminate();
        int c = ctl.get();
        if (runStateLessThan(c, STOP)) {
            if (!completedAbruptly) {
                int min = allowCoreThreadTimeOut ? 0 : CORE_POOL_SIZE;
                if (min == 0 && !isEmpty())
                    min = 1;
                if (workerCountOf(c) >= min)
                    return; // replacement not needed
            }
            addWorker(null);
        }
    }

    private Runnable getTask() {
        boolean timedOut = false; // Did the last poll() time out?
        for (; ; ) {
            int c = ctl.get();
            // Check if queue empty only if necessary.
            if (runStateAtLeast(c, SHUTDOWN) && (runStateAtLeast(c, STOP) || isEmpty())) {
                decrementWorkerCount();
                return null;
            }
            int wc = workerCountOf(c);
            // Are workers subject to culling?
            boolean timed = allowCoreThreadTimeOut || wc > CORE_POOL_SIZE;
            if ((wc > CORE_POOL_SIZE || (timed && timedOut))
                    && (wc > 1 || isEmpty())) {
                if (compareAndDecrementWorkerCount(c))
                    return null;
                continue;
            }
            try {
                Runnable r = timed ?
                        workQueue.poll(keepAliveTime, TimeUnit.NANOSECONDS) :
                        workQueue.take();
                if (r != null)
                    return r;
                timedOut = true;
            } catch (InterruptedException retry) {
                timedOut = false;
            }
        }
    }

    final void runWorker(Worker w) {
        Thread wt = Thread.currentThread();
        Runnable task = w.firstTask;
        w.firstTask = null;
        w.unlock(); // allow interrupts
        boolean completedAbruptly = true;
        try {
            while (task != null || (task = getTask()) != null) {
                w.lock();
                // If pool is stopping, ensure thread is interrupted;
                // if not, ensure thread is not interrupted.  This
                // requires a recheck in second case to deal with
                // shutdownNow race while clearing interrupt
                if ((runStateAtLeast(ctl.get(), STOP) || (Thread.interrupted() &&
                        runStateAtLeast(ctl.get(), STOP))) && !wt.isInterrupted())
                    wt.interrupt();
                try {
                    ////beforeExecute(wt, task);
                    try {
                        task.run();
                        ////afterExecute(task, null);
                    } catch (Throwable ex) {
                        ////afterExecute(task, ex);
                        throw ex;
                    }
                } finally {
                    task = null;
                    w.completedTasks++;
                    w.unlock();
                }
            }
            completedAbruptly = false;
        } finally {
            processWorkerExit(w, completedAbruptly);
        }
    }

    public List<Runnable> shutdownNow() {
        List<Runnable> tasks;
        final ReentrantLock mainLock = this.mainLock;
        mainLock.lock();
        try {
            checkShutdownAccess();
            advanceRunState(STOP);
            interruptWorkers();
            tasks = drainQueue();
        } finally {
            mainLock.unlock();
        }
        tryTerminate();
        return tasks;
    }

    public boolean isShutdown() {
        return runStateAtLeast(ctl.get(), SHUTDOWN);
    }

    /**
     * Used by ScheduledThreadPoolExecutor.
     */
    boolean isStopped() {
        return runStateAtLeast(ctl.get(), STOP);
    }

    public boolean isTerminating() {
        int c = ctl.get();
        return runStateAtLeast(c, SHUTDOWN) && runStateLessThan(c, TERMINATED);
    }

    public boolean isTerminated() {
        return runStateAtLeast(ctl.get(), TERMINATED);
    }

    public boolean awaitTermination(long timeout, TimeUnit unit)
            throws InterruptedException {
        long nanos = unit.toNanos(timeout);
        final ReentrantLock mainLock = this.mainLock;
        mainLock.lock();
        try {
            while (runStateLessThan(ctl.get(), TERMINATED)) {
                if (nanos <= 0L)
                    return false;
                nanos = termination.awaitNanos(nanos);
            }
            return true;
        } finally {
            mainLock.unlock();
        }
    }

    //
//    //    public void setThreadFactory(ThreadFactory threadFactory) {
////        if (threadFactory == null)
////            throw new NullPointerException();
////        this.threadFactory = threadFactory;
////    }
////
//    public ThreadFactory getThreadFactory() {
//        return threadFactory;
//    }
//
//    //
////    /**
////     * Sets a new handler for unexecutable tasks.
////     *
////     * @param handler the new handler
////     * @throws NullPointerException if handler is null
////     * @see #getRejectedExecutionHandler
////     */
////    public void setRejectedExecutionHandler(RejectedExecutionHandler handler) {
////        if (handler == null)
////            throw new NullPointerException();
////        this.handler = handler;
////    }
////
////    /**
////     * Returns the current handler for unexecutable tasks.
////     *
////     * @return the current handler
////     * @see #setRejectedExecutionHandler(RejectedExecutionHandler)
////     */
////    public RejectedExecutionHandler getRejectedExecutionHandler() {
////        return handler;
////    }
////
////    public void setCorePoolSize(int corePoolSize) {
////        if (corePoolSize < 0 || maximumPoolSize < corePoolSize)
////            throw new IllegalArgumentException();
////        int delta = corePoolSize - this.corePoolSize;
////        this.corePoolSize = corePoolSize;
////        if (workerCountOf(ctl.get()) > corePoolSize)
////            interruptIdleWorkers();
////        else if (delta > 0) {
////            // We don't really know how many new threads are "needed".
////            // As a heuristic, prestart enough new workers (up to new
////            // core size) to handle the current number of tasks in
////            // queue, but stop if queue becomes empty while doing so.
////            int k = Math.min(delta, workQueue.size());
////            while (k-- > 0 && addWorker(null, true)) {
////                if (workQueue.isEmpty())
////                    break;
////            }
////        }
////    }
////
////    public int getCorePoolSize() {
////        return corePoolSize;
////    }
////
    public boolean prestartCoreThread() {
        return workerCountOf(ctl.get()) < CORE_POOL_SIZE && addWorker(null);
    }

    //
//    void ensurePrestart() {
//        int wc = workerCountOf(ctl.get());
//        if (wc < corePoolSize)
//            addWorker(null, true);
//        else if (wc == 0)
//            addWorker(null, false);
//    }
//
//    public int prestartAllCoreThreads() {
//        int n = 0;
//        while (addWorker(null, true))
//            ++n;
//        return n;
//    }
//
//    //    public boolean allowsCoreThreadTimeOut() {
////        return allowCoreThreadTimeOut;
////    }
////
    public void allowCoreThreadTimeOut(boolean value) {
        if (value && keepAliveTime <= 0) {
            throw new IllegalArgumentException("Core threads must have nonzero keep alive times");
        }
        if (value != allowCoreThreadTimeOut) {
            allowCoreThreadTimeOut = value;
            if (value) {
                interruptIdleWorkers();
            }
        }
    }

//    public MyLinkedBlockingQueue<Runnable> getQueue() {
//        return workQueue;
//    }

    public void purge() {
        tryTerminate(); // In case SHUTDOWN and now empty
    }

    ////    /**
////     * Returns the approximate number of threads that are actively
////     * executing tasks.
////     *
////     * @return the number of threads
////     */
////    public int getActiveCount() {
////        final ReentrantLock mainLock = this.mainLock;
////        mainLock.lock();
////        try {
////            int n = 0;
////            for (Worker w : workers)
////                if (w.isLocked())
////                    ++n;
////            return n;
////        } finally {
////            mainLock.unlock();
////        }
////    }
////
////    /**
////     * Returns the largest number of threads that have ever
////     * simultaneously been in the pool.
////     *
////     * @return the number of threads
////     */
////    public int getLargestPoolSize() {
////        final ReentrantLock mainLock = this.mainLock;
////        mainLock.lock();
////        try {
////            return largestPoolSize;
////        } finally {
////            mainLock.unlock();
////        }
////    }
////
////    /**
////     * Returns the approximate total number of tasks that have ever been
////     * scheduled for execution. Because the states of tasks and
////     * threads may change dynamically during computation, the returned
////     * value is only an approximation.
////     *
////     * @return the number of tasks
////     */
////    public long getTaskCount() {
////        final ReentrantLock mainLock = this.mainLock;
////        mainLock.lock();
////        try {
////            long n = completedTaskCount;
////            for (Worker w : workers) {
////                n += w.completedTasks;
////                if (w.isLocked())
////                    ++n;
////            }
////            return n + workQueue.size();
////        } finally {
////            mainLock.unlock();
////        }
////    }
////
////    /**
////     * Returns the approximate total number of tasks that have
////     * completed execution. Because the states of tasks and threads
////     * may change dynamically during computation, the returned value
////     * is only an approximation, but one that does not ever decrease
////     * across successive calls.
////     *
////     * @return the number of tasks
////     */
////    public long getCompletedTaskCount() {
////        final ReentrantLock mainLock = this.mainLock;
////        mainLock.lock();
////        try {
////            long n = completedTaskCount;
////            for (Worker w : workers)
////                n += w.completedTasks;
////            return n;
////        } finally {
////            mainLock.unlock();
////        }
////    }
////
//    protected void beforeExecute(Thread t, Runnable r) {
//    }
//
//    protected void afterExecute(Runnable r, Throwable t) {
//    }
//
//    protected void terminated() {
//    }

    public interface RejectedExecutionHandler {

        void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor);

    }

    //
//    public static class CallerRunsPolicy implements RejectedExecutionHandler {
//        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
//            if (!e.isShutdown()) {
//                r.run();
//            }
//        }
//    }
//
    public static class AbortPolicy implements RejectedExecutionHandler {
        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
            throw new RejectedExecutionException("Task " + r.toString() +
                    " rejected from " +
                    e.toString());
        }
    }

    public static class DiscardPolicy implements RejectedExecutionHandler {
        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
        }
    }

    public static class DiscardOldestPolicy implements RejectedExecutionHandler {
        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
            if (!e.isShutdown()) {
                e.getQueue().poll();
                e.execute(r);
            }
        }
    }

    private final class Worker extends AbstractQueuedLongSynchronizer implements Runnable {
        private static final long serialVersionUID = 6138294804551838833L;
        final Thread thread;
        Runnable firstTask;
        volatile long completedTasks;

        Worker(Runnable firstTask) {
            setState(-1); // inhibit interrupts until runWorker
            this.firstTask = firstTask;
            this.thread = threadFactory.newThread(this);
        }

        //
        @Override
        public void run() {
            runWorker(this);
        }

        //
//        //
////        protected boolean isHeldExclusively() {
////            return getState() != 0;
////        }
////
////        protected boolean tryAcquire(int unused) {
////            if (compareAndSetState(0, 1)) {
////                setExclusiveOwnerThread(Thread.currentThread());
////                return true;
////            }
////            return false;
////        }
////
////        protected boolean tryRelease(int unused) {
////            setExclusiveOwnerThread(null);
////            setState(0);
////            return true;
////        }
////
        public void lock() {
            acquire(1);
        }

        public boolean tryLock() {
            return tryAcquire(1);
        }

        public void unlock() {
            release(1);
        }

        //
//        //
////        public boolean isLocked() {
////            return isHeldExclusively();
////        }
////
        void interruptIfStarted() {
            Thread t;
            if (getState() >= 0 && (t = thread) != null && !t.isInterrupted()) {
                try {
                    t.interrupt();
                } catch (SecurityException ignore) {
                }
            }
        }
    }

    // VarHandle mechanics
    private static final VarHandle CTL;
    private static final VarHandle HEAD;
    private static final VarHandle TAIL;
    private static final VarHandle WORKER;

    //    private static final VarHandle WNEXT;
//    private static final VarHandle WSTATUS;
//    private static final VarHandle WCOWAIT;
    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            CTL = l.findVarHandle(ThreadPoolExecutor.class, "ctl", int.class);
            HEAD = l.findVarHandle(ThreadPoolExecutor.class, "whead", int.class);
            TAIL = l.findVarHandle(ThreadPoolExecutor.class, "wtail", int.class);
            WORKER = l.findVarHandle(ThreadPoolExecutor.class, "worker", Worker.class);
//            WSTATUS = l.findVarHandle(StampedLock.WNode.class, "status", int.class);
//            WNEXT = l.findVarHandle(StampedLock.WNode.class, "next", StampedLock.WNode.class);
//            WCOWAIT = l.findVarHandle(StampedLock.WNode.class, "cowait", StampedLock.WNode.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public static void main(String[] args) {
        System.out.println(RUNNING);
        int c = ctlOf(RUNNING, 0);
        System.out.println(c);
        System.out.println(workerCountOf(c));
        System.out.println(SHUTDOWN);
    }
}
