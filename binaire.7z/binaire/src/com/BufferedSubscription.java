package com;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.locks.LockSupport;
import java.util.function.BiConsumer;

@SuppressWarnings("serial")
@jdk.internal.vm.annotation.Contended
final class BufferedSubscription<T> implements Subscription, ForkJoinPool.ManagedBlocker {
    long timeout;                      // Long.MAX_VALUE if untimed wait
    int head;                          // next position to take
    int tail;                          // next position to put
    final int maxCapacity;             // max buffer size
    final Object[] array;                    // buffer
    final Subscriber<? super T> subscriber;
    final BiConsumer<? super Subscriber<? super T>, ? super Throwable> onNextHandler;
    Executor executor;                 // null on error
    Thread waiter;                     // blocked producer thread
    Throwable pendingError;            // holds until onError issued
    BufferedSubscription<T> next;      // used only by publisher
    //    BufferedSubscription<T> nextRetry; // used only by publisher

    @jdk.internal.vm.annotation.Contended("c") // segregate
    volatile long demand;              // # unfilled requests
    @jdk.internal.vm.annotation.Contended("c")
    volatile int waiting;              // nonzero if producer blocked
    volatile int ctl;                  // atomic run state flags

    // ctl bit values
    static final int CLOSED = 0x01;  // if set, other bits ignored
    static final int ACTIVE = 0x02;  // keep-alive for consumer task
    static final int REQS = 0x04;  // (possibly) nonzero demand
    static final int ERROR = 0x08;  // issues onError when noticed
    static final int COMPLETE = 0x10;  // issues onComplete when done
    static final int RUN = 0x20;  // task is or will be running
    static final int OPEN = 0x40;  // true after subscribe

    static final long INTERRUPTED = -1L; // timeout vs interrupt sentinel

    BufferedSubscription(Subscriber<? super T> subscriber, Executor executor,
                         BiConsumer<? super Subscriber<? super T>, ? super Throwable> onNextHandler,
                         Object[] array, int maxBufferCapacity) {
        this.subscriber = subscriber;
        this.executor = executor;
        this.onNextHandler = onNextHandler;
        this.array = array;
        this.maxCapacity = maxBufferCapacity;
    }

    @Override
    public final void request(long n) {
        if (n > 0L) {
            for (; ; ) {
                long p = demand, d = p + n;  // saturate
                if (casDemand(p, d < p ? Long.MAX_VALUE : d)) {
                    break;
                }
            }
            startOnSignal(RUN | ACTIVE | REQS);
        } else {
            onError(new IllegalArgumentException("non-positive subscription request"));
        }
    }

    @Override
    public final void cancel() {
        onError(null);
    }

    final void onError(Throwable ex) {
        if (ex != null) {
            pendingError = ex;  // races are OK
        }
        int c;
        Object[] a;      // to null out buffer on async error
        if (((c = getAndBitwiseOrCtl(ERROR | RUN | ACTIVE)) & CLOSED) == 0) {
            if ((c & RUN) == 0) {
                tryStart();
            } else if ((a = array) != null) {
                Arrays.fill(a, null);
            }
        }
    }

    final boolean casDemand(long cmp, long val) {
        return DEMAND.compareAndSet(this, cmp, val);
    }

    final boolean weakCasCtl(int cmp, int val) {
        return CTL.weakCompareAndSet(this, cmp, val);
    }

    final int getAndBitwiseOrCtl(int bits) {
        return (int) CTL.getAndBitwiseOr(this, bits);
    }

    final long subtractDemand(int k) {
        long n = (long) (-k);
        return n + (long) DEMAND.getAndAdd(this, n);
    }

    final boolean isClosed() {
        return (ctl & CLOSED) != 0;
    }

//    final int estimateLag() {
//        int c = ctl, n = tail - head;
//        return ((c & CLOSED) != 0) ? -1 : (n < 0) ? 0 : n;
//    }

    final void startOnSignal(int bits) {
        if ((ctl & bits) != bits && (getAndBitwiseOrCtl(bits) & (RUN | CLOSED)) == 0) {
            tryStart();
        }
    }

    final void tryStart() {
        try {
            ConsumerTask<T> task = new ConsumerTask<T>(this);
            Executor e;
            if ((e = executor) != null) {// skip if disabled on error
                e.execute(task);
            }
        } catch (RuntimeException | Error ex) {
            getAndBitwiseOrCtl(ERROR | CLOSED);
            throw ex;
        }
    }

    //    final int offer(T item, boolean unowned) {
//        Object[] a;
//        int stat = 0, cap = ((a = array) == null) ? 0 : a.length;
//        int t = tail, i = t & (cap - 1), n = t + 1 - head;
//        if (cap > 0) {
//            boolean added;
//            if (n >= cap && cap < maxCapacity) // resize
//                added = growAndOffer(item, a, t);
//            else if (n >= cap || unowned)      // need volatile CAS
//                added = QA.compareAndSet(a, i, null, item);
//            else {                             // can use release mode
//                QA.setRelease(a, i, item);
//                added = true;
//            }
//            if (added) {
//                tail = t + 1;
//                stat = n;
//            }
//        }
//        return startOnOffer(stat);
//    }
//
//    final boolean growAndOffer(T item, Object[] a, int t) {
//        int cap = 0, newCap = 0;
//        Object[] newArray = null;
//        if (a != null && (cap = a.length) > 0 && (newCap = cap << 1) > 0) {
//            try {
//                newArray = new Object[newCap];
//            } catch (OutOfMemoryError ex) {
//            }
//        }
//        if (newArray == null)
//            return false;
//        else {                                // take and move items
//            int newMask = newCap - 1;
//            newArray[t-- & newMask] = item;
//            for (int mask = cap - 1, k = mask; k >= 0; --k) {
//                Object x = QA.getAndSet(a, t & mask, null);
//                if (x == null)
//                    break;                    // already consumed
//                else
//                    newArray[t-- & newMask] = x;
//            }
//            array = newArray;
//            VarHandle.releaseFence();         // release array and slots
//            return true;
//        }
//    }
//
//
//    final int retryOffer(T item) {
//        Object[] a;
//        int stat = 0, t = tail, h = head, cap;
//        if ((a = array) != null && (cap = a.length) > 0 &&
//                QA.compareAndSet(a, (cap - 1) & t, null, item))
//            stat = (tail = t + 1) - h;
//        return startOnOffer(stat);
//    }
//
//
//    final int startOnOffer(int stat) {
//        int c; // start or keep alive if requests exist and not active
//        if (((c = ctl) & (REQS | ACTIVE)) == REQS &&
//                ((c = getAndBitwiseOrCtl(RUN | ACTIVE)) & (RUN | CLOSED)) == 0)
//            tryStart();
//        else if ((c & CLOSED) != 0)
//            stat = -1;
//        return stat;
//    }
//
    final void onSubscribe() {
        startOnSignal(RUN | ACTIVE);
    }

    final void onComplete() {
        startOnSignal(RUN | ACTIVE | COMPLETE);
    }

    final void consume() {
        Subscriber<? super T> s;
        if ((s = subscriber) != null) {          // hoist checks
            subscribeOnOpen(s);
            long d = demand;
            for (int h = head, t = tail; ; ) {
                int c, taken;
                boolean empty;
                if (((c = ctl) & ERROR) != 0) {
                    closeOnError(s, null);
                    break;
                } else if ((taken = takeItems(s, d, h)) > 0) {
                    head = h += taken;
                    d = subtractDemand(taken);
                } else if ((d = demand) == 0L && (c & REQS) != 0)
                    weakCasCtl(c, c & ~REQS);    // exhausted demand
                else if (d != 0L && (c & REQS) == 0)
                    weakCasCtl(c, c | REQS);     // new demand
                else if (t == (t = tail)) {      // stability check
                    if ((empty = (t == h)) && (c & COMPLETE) != 0) {
                        closeOnComplete(s);      // end of stream
                        break;
                    } else if (empty || d == 0L) {
                        int bit = ((c & ACTIVE) != 0) ? ACTIVE : RUN;
                        if (weakCasCtl(c, c & ~bit) && bit == RUN)
                            break;               // un-keep-alive or exit
                    }
                }
            }
        }
    }

    final int takeItems(Subscriber<? super T> s, long d, int h) {
        Object[] a;
        int k = 0, cap;
        if ((a = array) != null && (cap = a.length) > 0) {
            int m = cap - 1, b = (m >>> 3) + 1; // min(1, cap/8)
            int n = (d < (long) b) ? (int) d : b;
            for (; k < n; ++h, ++k) {
                Object x = QA.getAndSet(a, h & m, null);
                if (waiting != 0) {
                    signalWaiter();
                }
                if (x == null) {
                    break;
                } else if (!consumeNext(s, x)) {
                    break;
                }
            }
        }
        return k;
    }

    final boolean consumeNext(Subscriber<? super T> s, Object x) {
        try {
            @SuppressWarnings("unchecked") T y = (T) x;
            if (s != null) {
                s.onNext(y);
            }
            return true;
        } catch (Throwable ex) {
            handleOnNext(s, ex);
            return false;
        }
    }

    final void handleOnNext(Subscriber<? super T> s, Throwable ex) {
        BiConsumer<? super Subscriber<? super T>, ? super Throwable> h;
        try {
            if ((h = onNextHandler) != null) {
                h.accept(s, ex);
            }
        } catch (Throwable ignore) {
        }
        closeOnError(s, ex);
    }


    final void subscribeOnOpen(Subscriber<? super T> s) {
        if ((ctl & OPEN) == 0 && (getAndBitwiseOrCtl(OPEN) & OPEN) == 0)
            consumeSubscribe(s);
    }

    final void consumeSubscribe(Subscriber<? super T> s) {
        try {
            if (s != null) // ignore if disabled
                s.onSubscribe(this);
        } catch (Throwable ex) {
            closeOnError(s, ex);
        }
    }

    final void closeOnComplete(Subscriber<? super T> s) {
        if ((getAndBitwiseOrCtl(CLOSED) & CLOSED) == 0) {
            consumeComplete(s);
        }
    }

    final void consumeComplete(Subscriber<? super T> s) {
        try {
            if (s != null) {
                s.onComplete();
            }
        } catch (Throwable ignore) {
        }
    }

    final void closeOnError(Subscriber<? super T> s, Throwable ex) {
        if ((getAndBitwiseOrCtl(ERROR | CLOSED) & CLOSED) == 0) {
            if (ex == null) {
                ex = pendingError;
            }
            pendingError = null;  // detach
            executor = null;      // suppress racing start calls
            signalWaiter();
            consumeError(s, ex);
        }
    }

    final void consumeError(Subscriber<? super T> s, Throwable ex) {
        try {
            if (ex != null && s != null) {
                s.onError(ex);
            }
        } catch (Throwable ignore) {
        }
    }

    // Blocking support
    final void signalWaiter() {
        Thread w;
        waiting = 0;
        if ((w = waiter) != null) {
            LockSupport.unpark(w);
        }
    }

    //
//
//
//    final void awaitSpace(long nanos) {
//        if (!isReleasable()) {
//            ////ForkJoinPool.helpAsyncBlocker(executor, this);
//            if (!isReleasable()) {
//                timeout = nanos;
//                try {
//                    do {
//                    } while (!this.isReleasable() &&
//                            !this.block());
//                    ////ForkJoinPool.managedBlock(this);
//                } catch (InterruptedException ie) {
//                    timeout = INTERRUPTED;
//                }
//                if (timeout == INTERRUPTED)
//                    Thread.currentThread().interrupt();
//            }
//        }
//    }
//
//
    @Override
    public final boolean isReleasable() {
        Object[] a;
        int cap;
        return ((ctl & CLOSED) != 0 || ((a = array) != null && (cap = a.length) > 0 &&
                QA.getAcquire(a, (cap - 1) & tail) == null));
    }

    @Override
    public final boolean block() {
        long nanos = timeout;
        boolean timed = (nanos < Long.MAX_VALUE);
        long deadline = timed ? System.nanoTime() + nanos : 0L;
        while (!isReleasable()) {
            if (Thread.interrupted()) {
                timeout = INTERRUPTED;
                if (timed) {
                    break;
                }
            } else if (timed && (nanos = deadline - System.nanoTime()) <= 0L) {
                break;
            } else if (waiter == null) {
                waiter = Thread.currentThread();
            } else if (waiting == 0) {
                waiting = 1;
            } else if (timed) {
                LockSupport.parkNanos(this, nanos);
            } else {
                LockSupport.park(this);
            }
        }
        waiter = null;
        waiting = 0;
        return true;
    }

    // VarHandle mechanics
    static final VarHandle DEMAND;
    static final VarHandle CTL;
    static final VarHandle QA;

    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            DEMAND = l.findVarHandle(BufferedSubscription.class, "demand", long.class);
            CTL = l.findVarHandle(BufferedSubscription.class, "ctl", int.class);
            QA = MethodHandles.arrayElementVarHandle(Object[].class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }

        // Reduce the risk of rare disastrous classloading in first call to
        // LockSupport.park: https://bugs.openjdk.java.net/browse/JDK-8074773
        Class<?> ensureLoaded = LockSupport.class;
    }
}