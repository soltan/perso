package com;

public class com {

    private static final int BITSHIFT = 5;
    private static final int BITMASK = (1 << BITSHIFT) - 1;
    static final long intmask = 0xffffffffffffffffL;

    public static void main(String[] args) {
//        long w = 256L;
        int index = 2;
        for (long i = 0; i < 256L; i++) {
            print(i, index);
        }
    }

    private static int getState(long word, final int index) {
        long bit = index << 1L;
        return (int) (0x3 & (word >> bit));
    }

    private static int setState(long word, final int index, int newValue) {
        long bit = index << 1L;
        return (int) (0x3 & (word >> bit));
    }


    public static void print(final long s, final int fromIndex) {
        String bits = Long.toBinaryString(s);
        while (bits.length() < 8) {
            bits = "0" + bits;
        }
        System.out.print(bits + " | ");
        int start = 6 - (fromIndex << 1);
        System.out.print(bits.substring(start, start + 2) + " | ");

        while (bits.length() < 3) {
            bits += " ";
        }
        System.out.print(bits + " | ");

        int index = (fromIndex << 1L);
        long r = s >> index;
        r &= 0x3;
        System.out.print(r + " | ");
        System.out.println(getState(s, fromIndex));
    }
}
